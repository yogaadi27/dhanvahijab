
<link href="<?=base_url()?>/assets/css/morris.css" rel="stylesheet"/>
<!-- Year Picker CSS -->
<link rel="stylesheet" href="<?=base_url()?>/assets/plugins/year-picker/css/yearpicker.css" />


<div class="container-fluid">
    <!-- <div class="select2-drpdwn"> -->
        <div class="row">
        <!-- Default Textbox start-->
        <!-- Default Textbox end-->
        <!-- Input Groups start-->
        <div class="col-sm-3">
            <div class="card">
                <div class="card-body">
                <form id="form-year">
                    <div class="form-group m-form__group">
                        <label>Pilih Tahun</label>
                        <div class="input-group mb-3">
                        <div class="input-group-prepend"><span class="input-group-text"><i class="fa fa-calendar"></i></span></div>
                            <input class="form-control" type="text" name="yearpicker" id="yearpicker" placeholder="">
                        </div>
                    </div>
                    <button class="btn btn-primary" type="submit"><i class="fa fa-send"></i>  Tampilkan</button>
                </form>
                </div>
            </div>
        </div>

        <div class="col-sm-9">
            <div class="card">
                <div class="card-header text-center">
                <h5 id="grafik-title"></h5>
                </div>
                <div class="card-body">
                  <div id="myfirstchart"></div>
                </div>
            </div>
        </div>
        <!-- Input Groups end-->
        </div>
    <!-- </div> -->
</div>
          <!-- Container-fluid Ends-->


<script src="<?=base_url()?>/assets/js/chart/morris-chart/raphael.js"></script>
<script src="<?=base_url()?>/assets/js/chart/morris-chart/morris.js"> </script>
<script src="<?=base_url()?>/assets/js/chart/morris-chart/prettify.min.js"></script>
<script src="<?=base_url()?>/assets/js/moment.js"></script>
<!-- Year Picker Js -->
<script src="<?=base_url()?>/assets/plugins/year-picker/js/yearpicker.js"></script>

<script>

    $(document).ready(function() {
        var tahun = <?=date('Y') ?>;
        chart(tahun); 

        $("#yearpicker").yearpicker({
            year: <?=date('Y')?>,
            startYear: 2018,
            endYear: 2050,
        });
    });

    $('#form-year').on('submit',function(e) {
       e.preventDefault();
       var tahun = $('#yearpicker').val();
       chart(tahun);
    });

   
    function chart(tahun) {
        $("#myfirstchart").empty();
        $.ajax({
            url: "<?=site_url('grafik/get_data_grafik')?>",
            method: "POST",
            data: {
                tahun: tahun
            },
            // dataType: "json", //parse the response data as JSON automatically
            success: function(data) {
                if (data=="success") {
                    Morris.Line({
                    element: 'myfirstchart',
                    data: [{
                                y: "2011",
                                a: 100,
                                b: 90,
                                c: 80
                            },
                            {
                                y: "2012",
                                a: 75,
                                b: 65
                            },
                            {
                                y: "2013",
                                a: 50,
                                b: 40
                            },
                            {
                                y: "2014",
                                a: 75,
                                b: 65
                            },
                            {
                                y: "2015",
                                a: 50,
                                b: 40
                            },
                            {
                                y: "2016",
                                a: 75,
                                b: 65
                            },
                            {
                                y: "2017",
                                a: 100,
                                b: 90
                            }],
                        xkey: "y",
                        ykeys: ["a", "b","c"],
                        labels: ["Series A", "Series B","Series C"]
                    
                    });
                }
            }
        });
    }

</script>

