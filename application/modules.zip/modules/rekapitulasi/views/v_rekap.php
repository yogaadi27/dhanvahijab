<div class="container-fluid">

<div class="row">
    <!-- Individual column searching (text inputs) Starts-->
    <div class="col-sm-12">
      <div class="card">
          <div class="card-header">
          <h5>Rekap Jumlah Produk Masuk </h5>
          </div>
          <div class="card-body">
            <!-- Simple demo-->      
            <div class="table-responsive product-table">
                <table class="display" id="table_per_produk">
                <thead>
                    <tr>
                    <th>Foto</th>
                    <th>Nama Produk</th>
                    <th>Jumlah Produksi</th>
                    <th>Status</th>
                    <th>Total Biaya Pemesanan</th>
                    <th></th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
                </table>
            </div>
          </div>
      </div>
    </div>
    <!-- Individual column searching (text inputs) Ends-->
</div>

<div class="row">
    <!-- Individual column searching (text inputs) Starts-->
    <div class="col-sm-12">
      <div class="card">
          <div class="card-header">
          <h5>Rekap Jumlah Produk Keluar </h5>
          </div>
          <div class="card-body">
            <!-- Simple demo-->      
            <div class="table-responsive product-table">
                <table class="display" id="table_produk_keluar">
                <thead>
                    <tr>
                    <th>Foto</th>
                    <th>Nama Produk</th>
                    <th>Jumlah Terjual</th>
                    <th>Status</th>
                    <th>Total Penjualan</th>
                    <th></th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
                </table>
            </div>
          </div>
      </div>
    </div>
    <!-- Individual column searching (text inputs) Ends-->
</div>

</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>
<script src="<?=base_url()?>/assets/js/autonumeric/autoNumeric.js"></script>

<script>
  
  $(document).ready(function() {

    var table2;
      //datatables per produk
      table2 = $('#table_per_produk').DataTable({ 

          "processing": true, 
          "serverSide": true, 
          "order": [], 
      
          "ajax": {
              "url": "<?php echo site_url('rekapitulasi/ajax_list_per_produk')?>",
              "type": "POST",
          },
          "dom": 'lBfrtip',
          "pageLength": 10, 
          buttons: [
              'copyHtml5',
              'excelHtml5',
              'csvHtml5',
              'pdfHtml5'
          ]
      });

  });

  var table;
      //datatables
      table = $('#table_produk_keluar').DataTable({ 

          "processing": true, 
          "serverSide": true, 
          "order": [], 
      
          "ajax": {
              "url": "<?php echo site_url('rekapitulasi/ajax_list_rekap_keluar')?>",
              "type": "POST",
          },
          "dom": 'lBfrtip',
          "pageLength": 10, 
          buttons: [
              'copyHtml5',
              'excelHtml5',
              'csvHtml5',
              'pdfHtml5'
          ]
      });

  function reload() {
        $("#table-produk").dataTable().api().ajax.reload( null, false );
  }

</script>