<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Rekapitulasi extends CI_Controller {

    
    public function __construct()
    {
        parent::__construct();
        //Do your magic here
        $this->load->model('Model_product_masuk','mp_masuk');
        $this->load->model('Model_product_keluar','mp_keluar');

		is_logged_in();

    }
    

    public function index()
    {
        $data['judul'] = 'Rekapitulasi Produk Masuk dan Keluar';
        $data['title'] = 'Rekapitulasi Produk Masuk dan Keluar';
		
		$this->template->load('v_rekap',$data);
    }

    public function bulanan($id_produk = null)
    {
        $this->db->select('id_produk,nama_produk');
        $this->db->where('user_id',$this->session->userdata('logged_in')['id_user']);
        $this->db->where('is_active',1);
        $data['list_produk'] = $this->db->get('produk')->result();

        # code...
        //  $bulan = array (1=>'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember');

        //  $opsi_bulan = '<select name="bulan">';
        //  foreach ($bulan as $key => $value) {
        //      $opsi_bulan .= '<option value="' . $key . '">' . $key . '</option>' . "\r\n";
        //  }
        //  $opsi_bulan .= '</select>';
         
         // echo number_format(01);
        //  echo $opsi_bulan;   
        // $opsi_bulan = '';
        // $bulan=array (
        //     1 => 'Januari',
        //     2 => 'Februari',
        //     3 => 'Maret',
        //     4 => 'April',
        //     5 => 'Mei',
        //     6 => 'Juni',
        //     7 => 'Juli',
        //     8 => 'Agustus',
        //     9 => 'September',
        //     10 => 'Oktober',
        //     11 => 'November',
        //     12 => 'Desember'
        // );
        
        // foreach ($bulan as $key => $value) {
        //     // $opsi_bulan .= $key."<br>";

        //     $this->db->select('tgl_brg_keluar,nama_produk, SUM(qty) AS jumlah_qty', FALSE);
        //     $this->db->from('produk_keluar_detail');
        //     $this->db->join('produk','produk.id_produk=produk_keluar_detail.produk_id');
        //     // $this->db->group_by('produk_id');
        //     $this->db->where('produk_id',$id_produk);
        //     $this->db->where('produk.user_id',$this->session->userdata('logged_in')['id_user']);
        //     $this->db->where('YEAR(tgl_brg_keluar)','2020');
        //     $this->db->where('MONTH(tgl_brg_keluar)',$key);
        //     $this->db->group_by('MONTH(tgl_brg_keluar), YEAR(tgl_brg_keluar)');
        //     $q=$this->db->get();
        //     $ret = ($q->num_rows() >0 ) ? $q->row()->jumlah_qty : 0 ;
        //     echo $value." : ".$ret."<br>";
        // }
        // // $opsi_bulan .= '</s?elect>';
        // die();
        // // echo number_format(01);
        // echo $opsi_bulan;   

         


        //  $q=$this->db->get();
        //  print_r($q->result());
        $data['judul'] = 'Rekapitulasi Penjualan Per Bulan';
        $data['title'] = 'Rekapitulasi Penjualan Per Bulan';
		
		$this->template->load('v_rekap_penjualan',$data);
    }

    public function produksi()
    {
            # code...
            // $bulan = array (1=>'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember');
        $opsi_bulan = '';
        $bulan=array (
            1 => 'Januari',
            2 => 'Februari',
            3 => 'Maret',
            4 => 'April',
            5 => 'Mei',
            6 => 'Juni',
            7 => 'Juli',
            8 => 'Agustus',
            9 => 'September',
            10 => 'Oktober',
            11 => 'November',
            12 => 'Desember'
        );

        $check = array();
        foreach ($arrayOne as $one) {
            $check[$one['one']] = true;
        }
        foreach ($arrayTwo as $two) {
            if (isset($check[$two])) {
                echo 'Match! <br/>';
            }
        }


        foreach ($bulan as $key => $value) {
            $opsi_bulan .= $key."<br>";
        }
        // $opsi_bulan .= '</s?elect>';

        // echo number_format(01);
        echo $opsi_bulan;   
        // die();
        $this->db->select('*, SUM(qty) AS jumlah_qty, SUM(total_biaya) AS jumlah_biaya', FALSE);
        $this->db->from($this->table);
        $this->db->join('produk','produk.id_produk=produk_keluar_detail.produk_id');
        // $this->db->group_by('produk_id');
        $this->db->group_by('MONTH(date), YEAR(date)');
        $this->db->where('produk.user_id',$this->session->userdata('logged_in')['id_user']);

            // $data['judul'] = 'Rekapitulasi Produksi Per Bulan';
            // $data['title'] = 'Rekapitulasi Produksi Per Bulan';
            
            // $this->template->load('v_rekap_produksi',$data);
    }

    public function get_data_jual($var = null)
    {
        # code...
        if ($this->input->is_ajax_request()) {
            # code...
            $bulan=array (
                1 => 'Januari',
                2 => 'Februari',
                3 => 'Maret',
                4 => 'April',
                5 => 'Mei',
                6 => 'Juni',
                7 => 'Juli',
                8 => 'Agustus',
                9 => 'September',
                10 => 'Oktober',
                11 => 'November',
                12 => 'Desember'
            );
            $rt=0;
            $rt_in=0;

            $html='';
            foreach ($bulan as $key => $value) {
                //penjualan
                $this->db->select('tgl_brg_keluar,nama_produk, SUM(qty) AS jumlah_qty', FALSE);
                $this->db->from('produk_keluar_detail');
                $this->db->join('produk','produk.id_produk=produk_keluar_detail.produk_id');
                // $this->db->group_by('produk_id');
                $this->db->where('produk_id',$this->input->post('produk_id',TRUE));
                $this->db->where('produk.user_id',$this->session->userdata('logged_in')['id_user']);
                $this->db->where('YEAR(tgl_brg_keluar)',$this->input->post('yearpicker'));
                $this->db->where('MONTH(tgl_brg_keluar)',$key);
                $this->db->group_by('MONTH(tgl_brg_keluar), YEAR(tgl_brg_keluar)');
                $q=$this->db->get();

                //pomesanan
                $this->db->select('tgl_masuk,nama_produk, SUM(jumlah_masuk) AS qty_in', FALSE);
                $this->db->from('produk_masuk');
                $this->db->join('produk','produk.id_produk=produk_masuk.produk_id');
                // $this->db->group_by('produk_id');
                $this->db->where('produk_id',$this->input->post('produk_id',TRUE));
                $this->db->where('produk.user_id',$this->session->userdata('logged_in')['id_user']);
                $this->db->where('YEAR(tgl_masuk)',$this->input->post('yearpicker'));
                $this->db->where('MONTH(tgl_masuk)',$key);
                $this->db->group_by('MONTH(tgl_masuk), YEAR(tgl_masuk)');
                $q2=$this->db->get();

                $ret = ($q->num_rows() >0 ) ? $q->row()->jumlah_qty : 0 ;
                $ret2 = ($q2->num_rows() >0 ) ? $q2->row()->qty_in : 0 ;
                
                // echo $value." : ".$ret."<br>";
                $rt += number_format($ret);
                $rata2=number_format($rt/$key,0);

                $rt_in += number_format($ret2);
                $rata2_in=number_format($rt_in/$key,0);


                $html.='  <tr>
                            <th scope="row">'.$key.'</th>
                            <td>'.$value.'</td>
                            <td>'.$ret2.'</td>
                            <td>'.$ret.'</td>
                            <td>'.$rata2_in.'</td>
                            <td>'.$rata2.'</td>
                            </tr>';
            }
            $data['table']=$html;
            $data['msg']='success';
            $data['title']='Rekapitulasi Tahun '.$this->input->post('yearpicker');
            // print_r($this->input->post());
            echo json_encode($data,JSON_PRETTY_PRINT);
        } else {
            # code...
            show_404();
        }
        
    }

    public function ajax_list_per_produk()
    {
          if ($this->input->is_ajax_request()) {
                # code...
                $status='';
                $list = $this->mp_masuk->get_datatables();
                $data = array();
                $no = $_POST['start'];
                
                foreach ($list as $l) {
                    $no++;
  
                    $row = array();
                    // $row[] = $no;
                    $row[] = '<img src="'.base_url('/uploads/product/'.$l->foto).'" width="64" height="64" alt="">';
                    $row[] = '<h6>'.$l->nama_produk.'</h6><span>'.$l->deskripsi_produk.'</span>';
                    $row[] = $l->jumlah_stok.' '.$l->satuan;
                    $row[] = $l->is_active == 1 ? '<span class="badge badge-primary">aktif</span>' : '<span class="badge badge-danger">nonaktif</span>';
                    $row[] = number_format($l->jumlah_biaya_produksi,0);
                    $row[] = '
                    <a href="'.site_url('rekapitulasi/produksi/'.$l->produk_id).'" class="btn btn-success" type="button" data-original-title="btn btn-danger btn-xs" title=""><i class="fa fa-print"></i> Rekap Per Bulan</a>
                    ';	 
                    $data[] = $row;
                }
    
                $output = array(
                                "draw" => $_POST['draw'],
                                "recordsTotal" => $this->mp_masuk->count_all(),
                                "recordsFiltered" => $this->mp_masuk->count_filtered(),
                                "data" => $data,
                        );
                //output to json format
                echo json_encode($output);
          }else{
              show_404();
          }
            
    }

    public function ajax_list_rekap_keluar()
    {
          if ($this->input->is_ajax_request()) {
                # code...
                $status='';
                $list = $this->mp_keluar->get_datatables();
                $data = array();
                $no = $_POST['start'];
                
                foreach ($list as $l) {
                    $no++;
  
                    $row = array();
                    // $row[] = $no;
                    $row[] = '<img src="'.base_url('/uploads/product/'.$l->foto).'" width="64" height="64" alt="">';
                    $row[] = '<h6>'.$l->nama_produk.'</h6><span>'.$l->deskripsi_produk.'</span>';
                    $row[] = $l->jumlah_qty.' '.$l->satuan;
                    $row[] = $l->is_active == 1 ? '<span class="badge badge-primary">aktif</span>' : '<span class="badge badge-danger">nonaktif</span>';
                    $row[] = number_format($l->jumlah_biaya,0);
                    $row[] = '
                    <a href="'.site_url('rekapitulasi/penjualan/'.$l->produk_id).'" class="btn btn-success" type="button" data-original-title="btn btn-danger btn-xs" title=""><i class="fa fa-print"></i> Rekap Per Bulan</a>
                    ';	 
                    $data[] = $row;
                }
    
                $output = array(
                                "draw" => $_POST['draw'],
                                "recordsTotal" => $this->mp_keluar->count_all(),
                                "recordsFiltered" => $this->mp_keluar->count_filtered(),
                                "data" => $data,
                        );
                //output to json format
                echo json_encode($output);
          }else{
              show_404();
          }
            
    }

}

/* End of file Rekapitulasi.php */

?>