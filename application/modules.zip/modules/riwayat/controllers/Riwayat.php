<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Riwayat extends CI_Controller {
    
    public function __construct()
    {
        parent::__construct();
        //Do your magic here
        $this->load->model('Model_detail_produk_masuk','mp_detail_masuk');
        $this->load->model('Model_riwayat_Keluar','mp_keluar');
		is_logged_in();

    }
    
    public function index()
    {
        show_404();
    }

    public function masuk($var = null)
    {
   
        $data['judul'] = 'Riwayat Produksi Produk';
        $data['title'] = 'Riwayat Produksi Produk';
		
		$this->template->load('v_riwayat_produksi',$data);
    
    }

    public function keluar($var = null)
    {
   
        $data['judul'] = 'Riwayat Produk Keluar';
        $data['title'] = 'Riwayat Produksi Keluar';
		
		$this->template->load('v_riwayat_terjual',$data);
    
    }

    public function ajax_list_produk_masuk()
    {
          if ($this->input->is_ajax_request()) {
                # code...
                $status='';
                $list = $this->mp_detail_masuk->get_datatables();
                $data = array();
                $no = $_POST['start'];

                foreach ($list as $l) {
                    $no++;
  
                    $row = array();
                    // $row[] = $no;
                    $row[] = tanggal($l->tgl_masuk);
                    $row[] = '<img src="'.base_url('/uploads/product/'.$l->foto).'" width="64" height="64" alt="">';
                    $row[] = '<h6>'.$l->nama_produk.'</h6><span>'.$l->deskripsi_produk.'</span>';
                    $row[] = number_format($l->hrg_beli,0);
                    $row[] = $l->jumlah_masuk.' '.$l->satuan;
                    $row[] = number_format($l->total_biaya_produksi,0);
                    $data[] = $row;
                }
    
                $output = array(
                                "draw" => $_POST['draw'],
                                "recordsTotal" => $this->mp_detail_masuk->count_all(),
                                "recordsFiltered" => $this->mp_detail_masuk->count_filtered(),
                                "data" => $data,
                        );
                //output to json format
                echo json_encode($output);
          }else{
              show_404();
          }
            
    }

    public function ajax_list_produk_keluar()
    {
        //   if ($this->input->is_ajax_request()) {
                # code...
                $status='';
                $list = $this->mp_keluar->get_datatables();
                $data = array();
                $no = $_POST['start'];
                // print_r($list);
                // die();
                foreach ($list as $l) {
                    $no++;
  
                    $row = array();
                    // $row[] = $no;
                    $row[] = tanggal($l->tgl_brg_keluar);
                    $row[] = '<img src="'.base_url('/uploads/product/'.$l->foto).'" width="64" height="64" alt="">';
                    $row[] = '<h6>'.$l->nama_produk.'</h6><span>'.$l->deskripsi_produk.'</span>';
                    $row[] = number_format($l->harga_jual,0);
                    $row[] = $l->qty.' '.$l->satuan;
                    $row[] = number_format($l->total_biaya,0);
                    $data[] = $row;
                }
    
                $output = array(
                                "draw" => $_POST['draw'],
                                "recordsTotal" => $this->mp_keluar->count_all(),
                                "recordsFiltered" => $this->mp_keluar->count_filtered(),
                                "data" => $data,
                        );
                //output to json format
                echo json_encode($output);
        //   }else{
        //       show_404();
        //   }
            
    }

}

/* End of file Riwayat.php */

?>