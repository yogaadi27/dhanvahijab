<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Grafik extends CI_Controller {

    
    public function __construct()
    {
        parent::__construct();
        //Do your magic here
        is_logged_in();
    }
    
  
    public function index()
    {
        $this->db->select('id_produk,nama_produk');
        $this->db->where('user_id',$this->session->userdata('logged_in')['id_user']);
        $this->db->where('is_active',1);
        $data['list_produk'] = $this->db->get('produk')->result();

        $data['judul'] = 'Grafik';
        $data['title'] = 'Grafik';

        // $this->db->select('id_produk,nama_produk');
        // $this->db->where('user_id',$this->session->userdata('logged_in')['id_user']);
        // $this->db->where('is_active',1); 
        // // Produces: WHERE name = 'Joe'
        // $data['list_produk'] = $this->db->get('produk')->result();
		// print_r($this->session->
		// print_r($this->session->userdata('logged_in'));
		$this->template->load('v_grafik',$data);
    }

    public function get_data_grafik($var = null)
    {
        if ($this->input->is_ajax_request()) {
            # code...
            $bulan=array (
                1 => 'Jan',
                2 => 'Feb',
                3 => 'Mar',
                4 => 'Apr',
                5 => 'Mei',
                6 => 'Jun',
                7 => 'Jul',
                8 => 'Agst',
                9 => 'Sept',
                10 => 'Okt',
                11 => 'Nov',
                12 => 'Des'
            );
            $rt=0;
            $rt_in=0;
            
            $row = array();

            $this->db->select('nama_produk,leadtime');
            $this->db->where('id_produk',$this->input->post('produk_id',TRUE));
            $dt_produk = $this->db->get('produk')->row();
            $produk = $dt_produk->nama_produk;

            $html='';
            foreach ($bulan as $key => $value) {
                //penjualan
                $this->db->select('tgl_brg_keluar,nama_produk, SUM(qty) AS jumlah_qty', FALSE);
                $this->db->from('produk_keluar_detail');
                $this->db->join('produk','produk.id_produk=produk_keluar_detail.produk_id');
                // $this->db->group_by('produk_id');
                $this->db->where('produk_id',$this->input->post('produk_id',TRUE));
                $this->db->where('produk.user_id',$this->session->userdata('logged_in')['id_user']);
                $this->db->where('YEAR(tgl_brg_keluar)',$this->input->post('yearpicker'));
                $this->db->where('MONTH(tgl_brg_keluar)',$key);
                $this->db->group_by('MONTH(tgl_brg_keluar), YEAR(tgl_brg_keluar)');
                $q=$this->db->get();

                //pomesanan
                $this->db->select('tgl_masuk,nama_produk, SUM(jumlah_masuk) AS qty_in', FALSE);
                $this->db->from('produk_masuk');
                $this->db->join('produk','produk.id_produk=produk_masuk.produk_id');
                // $this->db->group_by('produk_id');
                $this->db->where('produk_id',$this->input->post('produk_id',TRUE));
                $this->db->where('produk.user_id',$this->session->userdata('logged_in')['id_user']);
                $this->db->where('YEAR(tgl_masuk)',$this->input->post('yearpicker'));
                $this->db->where('MONTH(tgl_masuk)',$key);
                $this->db->group_by('MONTH(tgl_masuk), YEAR(tgl_masuk)');
                $q2=$this->db->get();

                $ret = ($q->num_rows() >0 ) ? $q->row()->jumlah_qty : 0 ;
                
                $row = [
                            "y" => $value,
                            "a" => $ret,
                            // "b" => 128
                        ];
                // $row[] = arr;
                $data[]= $row;

            }
            $data['grafik']=$data;
            $data['nama_produk']=$produk;
            // $data['table']=$html;
            $data['msg']='success';
            $data['title']='Grafik Penjualan Tahun '.$this->input->post('yearpicker').'<br> Produk : '.$produk;
            // print_r($this->input->post());
            // console.log($data);
            echo json_encode($data,JSON_PRETTY_PRINT);
        } else {
            # code...
            show_404();
        }
    }

}

/* End of file Grafik.php */

?>
