<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Registrasi extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Model_auth', 'm_auth');
      
    }

    private $skeleton = array(
		//form,database,label,validatioon
		array('username','username','Email Aktif','trim|required'),
		array('password','password','password','trim|required'),
		array('fullname','fullname','Nama UMKM','trim|max_length[255]'),
        array('alamat','alamat','alamat','trim|required'),
        array('lapangan_usaha_id','lapangan_usaha_id','lapangan_usaha_id','trim|required'),
	);

    public function index()
    {
      
        $data['title']='Registrasi';
        $data['lapangan_usaha'] = $this->db->get_where('lapangan_usaha', array('is_active' => 1));
        $this->template->load('registrasi_v',$data);

    }

    public function add()
	{
		if ($this->input->is_ajax_request()) {
				
                print_r($this->input->post());
                die();
				$form_unuse   = array();
				$user_data 	  = array();

				foreach ($this->skeleton as $key => $user) {
					// if (!in_array($user[0], $form_unuse)) {
					// 	$this->form_validation->set_rules($user[0], $user[2],$user[3]);
						if ($user[1]!=NULL) {
							$user_data[$user[1]] = $this->input->post($user[0],TRUE);
						}
					//}
				}
				//add custom 
				$user_data['file_siup'] = $data_siup['file_name'];
				$user_data['file_ktp'] = $data_ktp['file_name'];

				//paramaeter ( nama tabel, data )
				$q=$this->Model_app->insert('perusahaan',$user_data);
				$status='error';
				if ($q) {
					$kode_token=$this->_getToken();
					$this->_send_mail($kode_token,$user_data['email_penanggungjawab']);
					$data_login = array(
						'perusahaan_id' => $this->db->insert_id(),
						'role_id' => '2',
						'email' => $user_data['email_penanggungjawab'],
						'password' => getHashedPassword($this->input->post('password')),
						'fullname' => $user_data['nama_penanggungjawab'],
						'jabatan' => $user_data['jabatan_penanggungjawab'],
						'no_hp' => $this->input->post('no_hp'),
						'token'=>$kode_token
					);
					$query=$this->Model_app->insert('user_perusahaan',$data_login);
					if ($query) {
						// insert_log('buyer_create',sess_id());
						// echo $kode_token;
						// $this->_send_mail($kode_token);
						$status='success';
					}
				}
				echo $status;
			// print_r($user_data);
		}
	}

	private function _getToken()
	{
		$seed = str_split('ABCDEFGHIJKLMNOPQRSTUVWXYZ'
                     .'0123456789'); // and any other characters
		shuffle($seed); // probably optional since array_is randomized; this may be redundant
		$rand = '';
		foreach (array_rand($seed, 6) as $k) $rand .= $seed[$k];
		return $rand;
	}

	private function _send_mail($token='',$email='') { 

		$from_email = "operatorbos.ganteng@gmail.com"; 
		$to_email = $email; 

		$config = Array(
			   'protocol' => 'smtp',
			   'smtp_host' => 'ssl://smtp.googlemail.com',
			   'smtp_port' => 465,
			   'smtp_user' => $from_email,
			   'smtp_pass' => 'obkuncsreafxztgh',
			   'mailtype'  => 'html', 
			   'charset'   => 'iso-8859-1'
	   );

		   $this->load->library('email', $config);
		   $this->email->set_newline("\r\n");   

		$this->email->from($from_email, 'SI-LOKER'); 
		$this->email->to($to_email);
		$this->email->subject('Token Aktivasi'); 
		$this->email->message('Token aktivasi akun kamu : '.$token); 
		$this->email->send();
		//Send mail 
		// if($this->email->send()){
		 return true;
		// } 
	}

}

/* End of file  */
/* Location: ./application/controllers/ */