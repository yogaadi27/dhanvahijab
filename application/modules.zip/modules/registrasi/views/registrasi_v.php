     <!-- Advanced Form Example With Validation -->
     <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2><strong>REGISTRASI UMKM</strong></h2>
                        </div>
                        <div class="body">
                            <form id="wizard_with_validation" method="POST">
                                <h3>Informasi Akun</h3>
                                <fieldset>
                                    <div class="form-group form-float">
                                        <div class="form-line">
                                            <input type="email" class="form-control" name="email" required>
                                            <label class="form-label">Email Aktif*</label>
                                        </div>
                                    </div>
                                    <div class="form-group form-float">
                                        <div class="form-line">
                                            <input type="password" class="form-control" name="password" id="password" required>
                                            <label class="form-label">Password*</label>
                                        </div>
                                    </div>
                                    <div class="form-group form-float">
                                        <div class="form-line">
                                            <input type="password" class="form-control" name="confirm_password" required>
                                            <label class="form-label">Confirm Password*</label>
                                        </div>
                                    </div>
                                    <div class="form-group form-float">
                                        <div class="form-line">
                                            <select class="form-control">
                                            <option value="">-- Pilih Sektor Lapangan Usaha--</option>
                                                <?php foreach ($lapangan_usaha->result() as $value) { ?>
                                                    <option value="<?=$value->id_lapangan_usaha ?>"><?=$value->nama_lap_usaha?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                </fieldset>

                                <h3>Profile UMKM</h3>
                                <fieldset>
                                    <div class="form-group form-float">
                                        <div class="form-line">
                                            <input type="text" name="fullname" class="form-control" required>
                                            <label class="form-label">Nama UMKM*</label>
                                        </div>
                                    </div>
                                    <div class="form-group form-float">
                                        <div class="form-line">
                                            <textarea name="alamat" cols="30" rows="3" class="form-control no-resize" required></textarea>
                                            <label class="form-label">Alamat*</label>
                                        </div>
                                    </div>
                                    <div class="form-control form-float">
                                        <!-- <div class="form-line"> -->
                                            <select class="form-control">
                                            <!-- <option value="">-- Pilih Sektor Lapangan Usaha--</option> -->
                                            <?php foreach ($lapangan_usaha->result() as $value) { ?>
                                                <option value="<?=$value->id_lapangan_usaha ?>"><?=$value->nama_lap_usaha?></option>
                                            <?php } ?>
                                        </select>
                                        <!-- </div> -->
                                    </div>
                                    
                                </fieldset>

                                <h3>Syarat & Ketentuan - Selesai</h3>
                                <fieldset>
                                    <input id="acceptTerms-2" name="acceptTerms" type="checkbox" required>
                                    <label for="acceptTerms-2">I agree with the Terms and Conditions.</label>
                                </fieldset>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Advanced Form Example With Validation -->
<script>
$(function () {
    //Horizontal form basic

    //Advanced form with validation
    var form = $('#wizard_with_validation').show();
    form.steps({
        headerTag: 'h3',
        bodyTag: 'fieldset',
        transitionEffect: 'slideLeft',
        onInit: function (event, currentIndex) {
            $.AdminBSB.input.activate();

            //Set tab width
            var $tab = $(event.currentTarget).find('ul[role="tablist"] li');
            var tabCount = $tab.length;
            $tab.css('width', (100 / tabCount) + '%');

            //set button waves effect
            setButtonWavesEffect(event);
        },
        onStepChanging: function (event, currentIndex, newIndex) {
            if (currentIndex > newIndex) { return true; }

            if (currentIndex < newIndex) {
                form.find('.body:eq(' + newIndex + ') label.error').remove();
                form.find('.body:eq(' + newIndex + ') .error').removeClass('error');
            }

            form.validate().settings.ignore = ':disabled,:hidden';
            return form.valid();
        },
        onStepChanged: function (event, currentIndex, priorIndex) {
            setButtonWavesEffect(event);
        },
        onFinishing: function (event, currentIndex) {
            form.validate().settings.ignore = ':disabled';
            return form.valid();
        },
        onFinished: function (e) {
            e.preventDefault();
            var formData = new FormData(this);

            Swal.fire({
            title: 'Anda yakin ingin Daftar ?',
            html: "<p class='text-danger'><strong>Note : Pastikan Email Anda Aktif !</strong></p>",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Daftar Dekarang'
            }).then((result) => {

            if (result.value) {

                $.ajax({
                    method: "POST",
                    contentType:false,
                    catch:false,
                    processData:false,
                    data:formData,
                    url: "<?php echo site_url('registrasi/add') ?>",
                })
                .done(function( msg ) {
                console.log(msg);
                    // if (msg=='success') {
                    // Swal.fire({
                    //     title: "Pendaftaran Perusahaan Berhasil !",
                    //     text: "Silahkan Aktivasi Akun Anda",
                    //     type: "success"
                    // }).then(function() {
                    //     window.location.hash = 'perusahaan_pendaftaran/aktivasi_akun';
                    //     // window.location = "<?=site_url('auth');?>";
                    // });

                    // // toastr.success('Pendaftaran Perusahaan Berhasil, silakan aktivasi akun anda !');
                    //     $("#form-pendaftaran")[0].reset();
                    // // window.location.hash = 'perusahaan_pendaftaran/aktivasi_akun';

                    //     // $('.textarea').summernote('reset');
                    //     // reload();
                    // }else{
                    // toastr.error('Masalah pada server!');
                    // }
                    // return false;
                })
                .fail(function(jqXHR,textStatus,error) {
                    alert(error);
                    console.log(jqXHR.responseText);
                });

            }
            })


        }
    });

    form.validate({
        highlight: function (input) {
            $(input).parents('.form-line').addClass('error');
        },
        unhighlight: function (input) {
            $(input).parents('.form-line').removeClass('error');
        },
        errorPlacement: function (error, element) {
            $(element).parents('.form-group').append(error);
        },
        rules: {
            'confirm': {
                equalTo: '#password'
            }
        }
    });
});

function setButtonWavesEffect(event) {
    $(event.currentTarget).find('[role="menu"] li a').removeClass('waves-effect');
    $(event.currentTarget).find('[role="menu"] li:not(.disabled) a').addClass('waves-effect');
}
</script>