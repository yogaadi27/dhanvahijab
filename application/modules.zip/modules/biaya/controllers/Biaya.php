<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Biaya extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        //Do your magic here
        is_logged_in();
        $this->load->model('Model_penyimpanan','m_penyimpanan');
        $this->load->model('Model_pemesanan','m_pemesanan');

    }
    
    public function index()
    {
        show_404();
    }

    public function pemesanan($var = null)
    {
        $data['judul'] = 'Biaya Pemesanan';
        $data['title'] = 'Biaya Pemesanan';
        $this->db->select('id_produk,nama_produk');
        $this->db->where('user_id',$this->session->userdata('logged_in')['id_user']);
        $this->db->where('is_active',1); 
        // Produces: WHERE name = 'Joe'
        $data['list_produk'] = $this->db->get('produk')->result();
		$this->template->load('v_biaya_pemesanan',$data);
    }

    public function penyimpanan($var = null)
    {
        $data['judul'] = 'Biaya Penyimpanan';
        $data['title'] = 'Biaya Penyimpanan';
        $this->db->select('id_produk,nama_produk');
        $this->db->where('user_id',$this->session->userdata('logged_in')['id_user']);
        $this->db->where('is_active',1); 
        // Produces: WHERE name = 'Joe'
        $data['list_produk'] = $this->db->get('produk')->result();
		$this->template->load('v_biaya_penyimpanan',$data);
    }

    public function add_biaya_penyimpanan($var = null)
    {
        # code...
        if ($this->input->is_ajax_request()) {
            $data = array(
                    'produk_id' => $this->input->post('produk_id'),
                    'jenis_biaya_simpan' => $this->input->post('jenis_biaya'),
                    'jumlah_biaya_simpan' => $this->input->post('jum_biaya'),
            );
            
            $q=$this->db->insert('biaya_penyimpanan', $data);
            echo $q == TRUE ? 'success' : 'failed' ;    
        } else {
            show_404();
        }
    }

    public function add_biaya_pemesanan($var = null)
    {
        # code...
        if ($this->input->is_ajax_request()) {
            $data = array(
                    'produk_id' => $this->input->post('produk_id'),
                    'jenis_biaya_pesan' => $this->input->post('jenis_biaya'),
                    'jumlah_biaya_pesan' => $this->input->post('jum_biaya'),
            );
            
            $q=$this->db->insert('biaya_pemesanan', $data);
            echo $q == TRUE ? 'success' : 'failed' ;    
        } else {
            show_404();
        }
    }

    public function ajax_list_penyimpanan()
    {
          if ($this->input->is_ajax_request()) {
                # code...
                $status='';
                $list = $this->m_penyimpanan->get_datatables();
                $data = array();
                // print_r($list);
                // die();
                $no = $_POST['start'];
                foreach ($list as $l) {
                    $no++;
  
                    $row = array();
                    // $row[] = $no;

                    $row[] = '<img src="'.base_url('/uploads/product/'.$l->foto).'" width="64" height="64" alt="">';
                    $row[] = '<h6>'.$l->nama_produk.'</h6><span>'.$l->deskripsi_produk.'</span>';
                    $row[] = number_format($l->biaya_simpan,0);
                    // $row[] = $l->leadtime.' hari';
                    $row[] = $l->is_active == 1 ? '<span class="badge badge-primary">aktif</span>' : '<span class="badge badge-danger">nonaktif</span>';
                    $row[] = ' <a href="javascript:void(0);" onclick="get_detail(\''.$l->produk_id.'\')" class="btn btn-success btn-sm">Lihat Detail</a>
                              ';	 
                    // $row[] = '<img src="'.base_url().'/assets/foto_gtk/'.$l->foto.'" width="50" height="50" alt="1">';
                    $data[] = $row;
                }
    
                $output = array(
                                "draw" => $_POST['draw'],
                                "recordsTotal" => $this->m_penyimpanan->count_all(),
                                "recordsFiltered" => $this->m_penyimpanan->count_filtered(),
                                "data" => $data,
                        );
                //output to json format
    
                echo json_encode($output);
          }else{
              show_404();
          }
            
    }

    public function ajax_list_pemesanan()
    {
          if ($this->input->is_ajax_request()) {
                # code...
                $status='';
                $list = $this->m_pemesanan->get_datatables();
                $data = array();
                // print_r($list);
                // die();
                $no = $_POST['start'];
                foreach ($list as $l) {
                    $no++;
  
                    $row = array();
                    // $row[] = $no;

                    $row[] = '<img src="'.base_url('/uploads/product/'.$l->foto).'" width="64" height="64" alt="">';
                    $row[] = '<h6>'.$l->nama_produk.'</h6><span>'.$l->deskripsi_produk.'</span>';
                    $row[] = number_format($l->biaya_pemesanan,0);
                    // $row[] = $l->leadtime.' hari';
                    $row[] = $l->is_active == 1 ? '<span class="badge badge-primary">aktif</span>' : '<span class="badge badge-danger">nonaktif</span>';
                    $row[] = ' <a href="javascript:void(0);" onclick="get_detail(\''.$l->produk_id.'\')" class="btn btn-success btn-sm">Lihat Detail</a>
                              ';	 
                    // $row[] = '<img src="'.base_url().'/assets/foto_gtk/'.$l->foto.'" width="50" height="50" alt="1">';
                    $data[] = $row;
                }
    
                $output = array(
                                "draw" => $_POST['draw'],
                                "recordsTotal" => $this->m_pemesanan->count_all(),
                                "recordsFiltered" => $this->m_pemesanan->count_filtered(),
                                "data" => $data,
                        );
                //output to json format
    
                echo json_encode($output);
          }else{
              show_404();
          }
            
    }

    public function get_detail($var = null)
    {
        # code...
        $this->db->select('*');
        $this->db->from('biaya_penyimpanan');
        $this->db->join('produk','produk.id_produk=biaya_penyimpanan.produk_id');
        $this->db->where('biaya_penyimpanan.produk_id',$this->input->post('id',TRUE));
        // Produces: WHERE name = 'Joe'
        $data = $this->db->get()->result();
        // print_r($data);
        $html='';
        $no=1;
        foreach ($data as $key => $value) {
            $html.='<tr>
                        <th scope="row">'.$no.'</th>
                        <td>'.$value->jenis_biaya_simpan.'</td>
                        <td>'.number_format($value->jumlah_biaya_simpan,0).'</td>
                        <td><a href="javascript:void(0)" onclick="hapus_rincian(\''.$value->id_biaya_simpan.'\')" class="btn btn-danger btn-sm">Hapus</a></td>
                    </tr>';
            $no++;
        }
        echo $html;
    }

    public function get_detail_pemesanan($var = null)
    {
        # code...
        $this->db->select('*');
        $this->db->from('biaya_pemesanan');
        $this->db->join('produk','produk.id_produk=biaya_pemesanan.produk_id');
        $this->db->where('biaya_pemesanan.produk_id',$this->input->post('id',TRUE));
        // Produces: WHERE name = 'Joe'
        $data = $this->db->get()->result();
        // print_r($data);
        $html='';
        $no=1;
        foreach ($data as $key => $value) {
            $html.='<tr>
                        <th scope="row">'.$no.'</th>
                        <td>'.$value->jenis_biaya_pesan.'</td>
                        <td>'.number_format($value->jumlah_biaya_pesan,0).'</td>
                        <td><a href="javascript:void(0)" onclick="hapus_rincian(\''.$value->id_biaya_pemesanan.'\')" class="btn btn-danger btn-sm">Hapus</a></td>
                    </tr>';
            $no++;
        }
        echo $html;
    }

    public function hapus_rincian(Type $var = null)
    {
        # code...
        if ($this->input->is_ajax_request()) {
            $q=$this->db->delete('biaya_penyimpanan', array('id_biaya_simpan' => $this->input->post('id')));  // Produces: // DELETE FROM mytable  // WHERE id = $id
            echo $return = ($q==TRUE) ? 'success' : 'error';
        }
    }

    public function hapus_rincian_pemesanan(Type $var = null)
    {
        # code...
        if ($this->input->is_ajax_request()) {
            $q=$this->db->delete('biaya_pemesanan', array('id_biaya_pemesanan' => $this->input->post('id')));  // Produces: // DELETE FROM mytable  // WHERE id = $id
            echo $return = ($q==TRUE) ? 'success' : 'error';
        }
    }

}

/* End of file Biaya.php */
?>