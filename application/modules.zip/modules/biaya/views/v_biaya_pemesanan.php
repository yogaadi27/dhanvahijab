<div class="container-fluid">
  <div class="row">
      <!-- Individual column searching (text inputs) Starts-->
      <div class="col-sm-12">
        <div class="card">
            <div class="card-body">
              <button class="btn btn-primary" type="button" data-toggle="modal" data-original-title="test" data-target="#modal_add_pemesanan">Tambah <?=$title?></button>
              
              <div class="table-responsive product-table">
                  <table class="display" id="table-pemesanan">
                  <thead>
                      <tr>
                      <th>Foto</th>
                      <th>Nama Produk</th>
                      <th>Total Biaya Pemesanan</th>
                      <th>Status</th>
                      <th>Aksi</th>
                      </tr>
                  </thead>
                  <tbody>
                  </tbody>
                  </table>
              </div>
            </div>
        </div>
      </div>
      <!-- Individual column searching (text inputs) Ends-->
  </div>

<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myLargeModalLabel">Rincian Biaya Pemesanan</h4>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
      </div>
      <div class="modal-body">
        <div class="col-sm-12 col-lg-12 col-xl-12">
            <div class="table-responsive">
              <table class="table">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Jenis Biaya Pesan</th>
                    <th scope="col">Total</th>
                    <th scope="col">Aksi</th>
                  </tr>
                </thead>
                <tbody id="detail_table">
                </tbody>
              </table>
            </div>
          </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary" id="closemodal" type="button" data-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>



</div>


<!-- Modal Produksi -->
<div class="modal fade" id="modal_add_pemesanan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
          <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Form Tambah <?=$title?></h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
          </div>
          <form class="theme-form" id="form-add-pemesanan">
          <div class="modal-body">
          <div class="col-md-12">
            <div class="col-form-label">Pilih Product</div>
            <select class="form-control form-control-primary btn-square" id="produk_id" name="produk_id" required>
            <option>-- Pilih Product --</option>  
              <?php foreach ($list_produk as $key => $value) { ?>
                <option value="<?=$value->id_produk?>"><?=$value->nama_produk?></option>  
              <?php }?>
            </select>
          </div>
          <div class="col-md-12">
            <div class="col-form-label">Jenis Biaya</div>
              <input class="form-control" id="jenis_biaya" type="text" name="jenis_biaya" placeholder="Masukan Jenis Biaya" required>
          </div>
          <div class="col-md-12">
            <div class="col-form-label">Jumlah Biaya ( per produk )</div>
              <input class="form-control" id="jum_biaya" type="number" name="jum_biaya" placeholder="Masukan jumlah biaya" required>
          </div>     
          <div class="modal-footer">
          <button class="btn btn-primary" type="button" data-dismiss="modal">Tutup</button>
          <button class="btn btn-secondary" type="submit" name="submit">Tambahkan</button>
          </div>
          </form>
      </div>
    </div>
</div>




<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>
<script>
  $('#form-add-pemesanan').validator().on('submit', function (e) {
    if (e.isDefaultPrevented()) {
      // handle the invalid form...
      // console.log("gaga");
      $.notify({
          title: '<strong>Gagal !</strong>',
          message: 'Semua Form Wajib di isi !'
      },{
          type: 'danger',
          z_index: 2000,
      });
    } else {

      e.preventDefault();

      var formData = new FormData(this);

      Swal.fire({
      title: 'Anda yakin ingin menambah rincian biaya pemesanan ?',
      text: "Pastikan data yang anda masukan benar !",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Ya, Simpan !'
      }).then((result) => {
      if (result.isConfirmed) {
      
          $.ajax({
              method: "POST",
              contentType:false,
              catch:false,
              processData:false,
              data:formData,
              url: "<?=site_url('biaya/add_biaya_pemesanan') ?>",
              })
              .done(function(data) {
                  // console.log(data);
                  if (data=='success') {
                  Swal.fire(
                      'Berhasil !',
                      'Biaya Pemesanan berhasil disimpan !',
                      'success'
                      );
                  $('#modal_add_pemesanan').modal('hide');
                  $("#form-add-pemesanan")[0].reset();
                  reload();
                  }else{
                      alert('problem in the server');
                  }
              });       

      }
      })
    }
  });

  $(document).ready(function() {
    var table;
      //datatables
      table = $('#table-pemesanan').DataTable({ 

          "processing": true, 
          "serverSide": true, 
          "order": [], 
      
          "ajax": {
              "url": "<?php echo site_url('biaya/ajax_list_pemesanan')?>",
              "type": "POST",
            
          },
          
          "dom": 'lBfrtip',
          "pageLength": 10, 
          buttons: [
              'copyHtml5',
              'excelHtml5',
              'csvHtml5',
              'pdfHtml5'
          ]
      });
  });

  function reload() {
        $("#table-pemesanan").dataTable().api().ajax.reload( null, false );
  }

  function get_detail(id) {
        $.ajax({
            method: "POST",
            url: "<?=site_url('biaya/get_detail_pemesanan') ?>",
            data: { id:id }
          })
            .done(function(data) {
             
              $(".bd-example-modal-lg").modal("show");
              $('#detail_table').html(data);
             
                // console.log(data);
            
            });
  }

  function hapus_rincian(id) {

    Swal.fire({
      title: 'Anda yakin ingin manghhapus rincian biaya pemesanan ?',
      html: '<div class="alert alert-danger">Data akan dihapus secara permanen !</div>',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Ya, Hapus !'
      }).then((result) => {
      if (result.isConfirmed) {
      
        $.ajax({
            method: "POST",
            url: "<?=site_url('biaya/hapus_rincian_pemesanan') ?>",
            data: { id:id }
          })
            .done(function(data) {
            
              if (data=='success') {
                $.notify({
                  title: "<strong>Sukses !</strong> ",
                  message: "Berhasil di hapus !"

                },{
                    type: 'info'
                });
                reload();
                $('.bd-example-modal-lg').modal('hide');
                $('body').removeClass('modal-open');
                $('.modal-backdrop').remove();
              }else{
                $.notify({
                  title: "<strong>Error 500 !</strong> ",
                  message: "Masalah pada server !"

                },{
                    type: 'danger'
                });
              }



            });

      }
    })

  }

  $("#closemodal").click(function(e) {
    e.preventDefault();
    $('.bd-example-modal-lg').modal('hide');
    $('body').removeClass('modal-open');
    $('.modal-backdrop').remove();
  });
</script>