<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Model_product','m_produk');

        $this->load->model('Model_cart','m_cart');

        // // is_logged_in();
        is_logged_in();


    }

    public function index()
    {
        $data['judul'] = 'Product';
        $data['title'] = 'Product';

        $this->db->select('id_produk,nama_produk');
        $this->db->where('user_id',$this->session->userdata('logged_in')['id_user']);
        $this->db->where('is_active',1); 
        // Produces: WHERE name = 'Joe'
        $data['list_produk'] = $this->db->get('produk')->result();
		// print_r($this->session->
		// print_r($this->session->userdata('logged_in'));
		
		$this->template->load('v_product',$data);
    }

    public function ajax_list_produk()
    {
          if ($this->input->is_ajax_request()) {
                # code...
                $status='';
                $list = $this->m_produk->get_datatables();
                $data = array();
                $no = $_POST['start'];
                foreach ($list as $l) {
                    $no++;
  
                    $row = array();
                    // $row[] = $no;

                    $row[] = '<img src="'.base_url('/uploads/product/'.$l->foto).'" width="64" height="64" alt="">';
                    $row[] = '<h6>'.$l->nama_produk.'</h6><span>'.$l->deskripsi_produk.'</span>';
                    $row[] = number_format($l->harga_beli,0);
                    $row[] = number_format($l->harga_jual,0);
                    $row[] = $l->leadtime.' hari';
                    $row[] = $l->stok == null ? '0 '.$l->satuan : $l->stok.' '.$l->satuan;
                    $row[] = $l->is_active == 1 ? '<span class="badge badge-primary">aktif</span>' : '<span class="badge badge-danger">nonaktif</span>';
                    $row[] = ' <button class="btn btn-danger btn-xs" type="button" data-original-title="btn btn-danger btn-xs" title="">Delete</button>
                              <button class="btn btn-success btn-xs" type="button" data-original-title="btn btn-danger btn-xs" title="">Edit</button>
                              ';	 
                    // $row[] = '<img src="'.base_url().'/assets/foto_gtk/'.$l->foto.'" width="50" height="50" alt="1">';
                    $data[] = $row;
                }
    
                $output = array(
                                "draw" => $_POST['draw'],
                                "recordsTotal" => $this->m_produk->count_all(),
                                "recordsFiltered" => $this->m_produk->count_filtered(),
                                "data" => $data,
                        );
                //output to json format
    
                echo json_encode($output);
          }else{
              show_404();
          }
            
    }

    public function add_product($var = null)
	{
		if ($this->input->is_ajax_request()) {
			
        $config['upload_path']          = './uploads/product/';
		$config['allowed_types']        = 'jpeg|jpg|png';
		$config['max_size']             = 400;
		$config['encrypt_name']         = TRUE;
		// $config['max_width']            = 600;
		// $config['max_height']           = 600;

		$this->load->library('upload', $config);
		$this->upload->initialize($config);

            if ( ! $this->upload->do_upload('userfile'))
            {
                    $error = array('error' => $this->upload->display_errors());
                    // print_r($error);
                    // $this->session->set_flashdata('error',err_msg('File tidak terupload'));
                    // redirect('makanan/tambah','refresh');
                    echo 'gagal';
                    // $this->load->view('upload_form', $error);
            }
            else
            {
                    $data = array('upload_data' => $this->upload->data());
                    $data2 = array(
                        'user_id' => $this->session->userdata('logged_in')['id_user'],
                        'nama_produk' => $this->input->post('nama_produk'),
                        'deskripsi_produk' => $this->input->post('deskripsi_produk'),
                        'satuan' => $this->input->post('satuan'),
                        'stok' => 0,
                        'harga_beli' => $this->input->post('harga_beli'),
                        'harga_jual' => $this->input->post('harga_jual'),
                        'leadtime' => $this->input->post('lead_time'),
                        'foto' => $data['upload_data']['file_name'],
                    );
                    $this->db->insert('produk', $data2);
                    // redirect('makanan','refresh');
                    // print_r($data2);
                    // $this->load->view('upload_success', $data);
                    echo 'success';
                    // print_r($data2);
            }

		}else{
			show_404();
		}
    }
    
    public function add_stock($var = null)
    {
        if ($this->input->is_ajax_request()) {
            // print_r($this->input->post());
            $data = array(
                    'tgl_masuk' => date("Y-m-d",strtotime($this->input->post('tgl_produksi',TRUE))),
                    'produk_id' => $this->input->post('produk_id'),
                    'hrg_beli' => $this->input->post('hrg_beli'),
                    'jumlah_masuk' => $this->input->post('stok'),
                    'total_biaya_produksi' => $this->input->post('biaya_produksi'),
            );
            
            $q=$this->db->insert('produk_masuk', $data);
            if($q==TRUE){
                $this->db->where('id_produk', $this->input->post('produk_id'));
                $this->db->set('stok', 'stok+'.$this->input->post('stok'), FALSE);
                $q2=$this->db->update('produk');
                echo $q2 == TRUE ? 'success' : 'failed' ;    
            }else{
                echo 'failed';
            }
        } else {
            show_404();
        }
        
    }

    public function get_harga($var = null)
    {
        if ($this->input->is_ajax_request()) {
            $this->db->select('harga_beli');
            $this->db->where('id_produk',$this->input->post('id',TRUE));
            $query = $this->db->get('produk')->row();
            echo json_encode($query,JSON_PRETTY_PRINT);
        } else {
            show_404();
        }
        
    }

    public function get_harga_jual($var = null)
    {
        if ($this->input->is_ajax_request()) {
            $this->db->select('stok,harga_jual');
            $this->db->where('id_produk',$this->input->post('id',TRUE));
            $query = $this->db->get('produk')->row();
            echo json_encode($query,JSON_PRETTY_PRINT);
        } else {
            show_404();
        }
        
    }

    // -------------------Produk Keluar Function-------------------------
    public function keluar($var = null)
    {
        $data['judul'] = 'Product Keluar';
        $data['title'] = 'Product Keluar';

        $this->db->select('id_produk,nama_produk');
        $this->db->where('user_id',$this->session->userdata('logged_in')['id_user']);
        $this->db->where('is_active',1); 
        // Produces: WHERE name = 'Joe'
        $data['list_produk'] = $this->db->get('produk')->result();
		
		$this->template->load('v_product_keluar',$data);
    }

    public function add_cart($var = null)
    {
        if ($this->input->is_ajax_request()) {
            // print_r($this->input->post());
            $data = array(
                    'tgl_brg_keluar' => date("Y-m-d",strtotime($this->input->post('tgl_brg_keluar',TRUE))),
                    'produk_id' => $this->input->post('produk_id'),
                    'harga_jual' => $this->input->post('harga_jual'),
                    'qty' => $this->input->post('qty'),
                    'total_biaya' => $this->input->post('harga_jual')*$this->input->post('qty'),
                    'user_id' => $this->session->userdata('logged_in')['id_user'],
            );
            
            $q=$this->db->insert('produk_keluar_detail', $data);
            if($q==TRUE){
                $this->db->where('id_produk', $this->input->post('produk_id'));
                $this->db->set('stok', 'stok-'. $this->input->post('qty'), FALSE);
                $q2=$this->db->update('produk');
                $return = ( $q2 == true ) ? 'success' : 'failed' ;
                echo $return;
            }else{
                echo 'failed';
            }
        } else {
            show_404();
        }
        
    }

    public function ajax_list_cart()
    {
        //   if ($this->input->is_ajax_request()) {
                # code...
                $status='';
                $list = $this->m_cart->get_datatables();
                $data = array();
                $no = $_POST['start'];
                // print_r($list);
                // die();
                $total = 0;
                $total_sum = 0;
                foreach ($list as $l) {
                    $no++;
  
                    $row = array();
                    // $row[] = $no;
                    $row[] = '<img src="'.base_url('/uploads/product/'.$l->foto).'" width="64" height="64" alt="">';
                    $row[] = '<div class="product-name">'.$l->nama_produk.'</div>';
                    $row[] = number_format($l->harga_jual,0);
                    $row[] = $l->qty;
                    $row[] = '<div class="btn-group" role="group" aria-label="Basic example">
                                <a class="btn btn-outline-warning txt-danger" type="button"><i class="fa fa-minus fa-lg"></i></a>
                                <a class="btn btn-outline-warning txt-danger" type="button"><i class="fa fa-plus fa-lg"></i></a>
                                <a class="btn btn-outline-warning txt-danger" type="button"><i class="fa fa-trash fa-lg"></i></a>
                            </div>';
                    $row[] = number_format($total=$l->qty*$l->harga_jual,0);
                    $data[] = $row;
                    $total_sum+=$total;
                }
    
                $output = array(
                                "draw" => $_POST['draw'],
                                "recordsTotal" => $this->m_cart->count_all(),
                                "recordsFiltered" => $this->m_cart->count_filtered(),
                                "data" => $data,
                                "jumlah_bayar" =>$total_sum,
                        );
                //output to json format
                echo json_encode($output);
        //   }else{
        //       show_404();
        //   }
            
    }

    public function rincian_cart($var = null)
    {
        if ($this->input->is_ajax_request()) {

                  // $this->db->select('*, SUM(jumlah_masuk) AS jumlah_stok, , SUM(total_biaya_produksi) AS jumlah_biaya_produksi', FALSE);
                $this->db->select('*');
                $this->db->from('produk_keluar_detail');
                $this->db->join('produk','produk.id_produk=produk_keluar_detail.produk_id');
                $this->db->where('produk.user_id',$this->session->userdata('logged_in')['id_user']);
                $this->db->where('produk_keluar_id',NULL);
                $q=$this->db->get();
                // die();
                // print_r($q);
                $data=array();
                $html='';
                $total_sum=0;

                foreach ($q->result() as $l) {
                    $html.='<tr>
                            <td>
                                <img src="'.base_url('/uploads/product/'.$l->foto).'" width="64" height="64" alt="">
                            </td>';
                    $html.='<td><div class="product-name">'.$l->nama_produk.'</div></td>';
                    $html.='<td>'.number_format($l->harga_jual,0).'</td>';
                    $html.='<td>'.$l->qty.'</td>';
                    $html.='<td>
                                <div class="btn-group" role="group" aria-label="Basic example">
                                    <a href="javascript:void(0)" onclick="minus_qty(\''.$l->id_detail_keluar.'\')" class="btn btn-outline-warning txt-danger" type="button"><i class="fa fa-minus"></i></a>
                                    <a href="javascript:void(0)" onclick="tambah_qty(\''.$l->id_detail_keluar.'\')" class="btn btn-outline-warning txt-danger" type="button"><i class="fa fa-plus"></i></a>
                                    <a href="javascript:void(0)" onclick="delete_cart(\''.$l->id_detail_keluar.'\')" class="btn btn-outline-warning txt-danger" type="button"><i class="fa fa-trash"></i></a>
                                </div>
                            </td>';
                    $html.='<td>'.number_format($total=$l->qty*$l->harga_jual,0).'</td>';
                    $total_sum+=$total;
                }
                $foot='
                        <tr>
                            <td class="total-amount"> 
                                <h6> <span>Pembeli :</span></h6>
                            </td>
                            <td class="total-amount" colspan="3"> 
                                <div class="form-group">
                                    <input class="form-control" id="nama_distributor" type="text" name="nama_distributor">
                                </div>
                            </td>
                            <td class="total-amount" colspan="1"> 
                                <h6> <span>Jumlah :</span></h6>
                            </td>
                            <td>
                                <div class="form-group">
                                    <input class="form-control" id="total_sum" type="text" name="total_sum" readonly>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="total-amount"> 
                                <h6> <span>Alamat :</span></h6>
                            </td>
                            <td class="total-amount" colspan="3" rowspan="2"> 
                                <div class="form-group">
                                    <textarea class="form-control" id="nama_distributor" type="text" name="nama_distributor"></textarea>
                                </div>
                            </td>
                            <td class="total-amount" colspan="1"> 
                            <h6> <span>Bayar :</span></h6>
                            </td>
                            <td>
                                <div class="form-group">
                                    <input class="form-control" id="bayar" type="number" name="bayar">
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="total-amount" colspan="5"> 
                            <h6> <span>Jumlah :</span></h6>
                            </td>
                            <td>
                                <div class="form-group">
                                    <input class="form-control" id="kembali" type="number" name="kembali" readonly>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="5"><a class="btn btn-primary cart-btn-transform" href="#">continue shopping</a></td>
                            <td><a class="btn btn-primary cart-btn-transform" href="#">check out</a></td>
                        </tr>
                        ';
                $data['rincian']=$html;
                $data['total_sum']=$total_sum;
               
                echo json_encode($data,JSON_PRETTY_PRINT);
                // // print_r($query);
        }else{
            show_404();
        }
    }

    public function tambah_qty($value='')
    {
        if ($this->input->is_ajax_request()) {
            $msg='false';
            $this->db->select('id_detail_keluar, produk_id');
            $this->db->where('id_detail_keluar',$this->input->post('id', TRUE));
            $query = $this->db->get('produk_keluar_detail')->row();
            
            if ($query==true) {
                $this->db->select('id_produk, stok');
                $this->db->where('id_produk',$query->produk_id);
                $query2 = $this->db->get('produk')->row();
                if ($query2->stok == 0) {
                    $msg='empty';
                }else{
                    $this->db->where('id_produk',$query->produk_id);
                    $this->db->where('user_id',$this->session->userdata('logged_in')['id_user']);
                    $this->db->set('stok', 'stok-1', FALSE);
                    $q=$this->db->update('produk');      
        
                    if ($q==true) {
        
                        $this->db->where('id_detail_keluar',$this->input->post('id', TRUE));
                        $this->db->where('user_id',$this->session->userdata('logged_in')['id_user']);
                        $this->db->set('qty', 'qty+1', FALSE);
                        $q2=$this->db->update('produk_keluar_detail');
        
                        if ($q2==true) {
                            $msg='success';
                        }
                    }
                }
            }
            echo $msg;
        }
    }

    public function minus_qty($value='')
    {
        if ($this->input->is_ajax_request()) {
            $msg='false';
            $this->db->select('id_detail_keluar, produk_id, qty');
            $this->db->where('id_detail_keluar',$this->input->post('id', TRUE));
            $query = $this->db->get('produk_keluar_detail')->row();
            
            if ($query->qty == 0) {
                
                $msg='empty';

            }else{
                // $msg='ada';
                $this->db->where('id_produk',$query->produk_id);
                $this->db->where('user_id',$this->session->userdata('logged_in')['id_user']);
                $this->db->set('stok', 'stok+1', FALSE);
                $q=$this->db->update('produk');      
    
                if ($q==true) {
    
                    $this->db->where('id_detail_keluar',$this->input->post('id', TRUE));
                    $this->db->where('user_id',$this->session->userdata('logged_in')['id_user']);
                    $this->db->set('qty', 'qty-1', FALSE);
                    $q2=$this->db->update('produk_keluar_detail');
    
                    if ($q2==true) {
                        $msg='success';
                    }
                }


            }
            echo $msg;
        }
    }

    public function delete_cart($value='')
    {
        if ($this->input->is_ajax_request()) {
            $msg=false;
            $id_brg=$this->input->post('id', TRUE);
            $this->db->select('produk_id,qty');
            $this->db->from('produk_keluar_detail');
            $this->db->where('id_detail_keluar',$id_brg);
            $data = $this->db->get()->row();
            if ($data==true) {
                $this->db->where('id_produk',$data->produk_id);
                $this->db->set('stok', 'stok+'.$data->qty, FALSE);
                $q=$this->db->update('produk');
                $delete=$this->db->delete('produk_keluar_detail', array('id_detail_keluar' => $id_brg));  
                if ($q==true) {
                    $msg='success';
                }
            }
            echo $msg;
        }
    }

    public function add_transaksi($var = null)
    {
        if ($this->input->is_ajax_request()) {
            // print_r($this->input->post());
        
            $data = array(
                    'tgl_transaksi' => date("Y-m-d",strtotime($this->input->post('tgl_transaksi',TRUE))),
                    'user_id' => $this->session->userdata('logged_in')['id_user'],
                    'nama_distributor' => $this->input->post('nama_distributor',TRUE),
                    'alamat_distributor' => $this->input->post('alamat_distributor',TRUE),
                    'total_bayar' => $this->input->post('total_sum',TRUE),
                    'bayar' => $this->input->post('bayar',TRUE),
                    'kembali' => $this->input->post('kembali',TRUE),
            );
            
            $q=$this->db->insert('produk_keluar', $data);
            $id=$this->db->insert_id();
            if($q==TRUE){
                $this->db->where('produk_keluar_id',NULL);
                $this->db->set('produk_keluar_id', $id, FALSE);
                $q2=$this->db->update('produk_keluar_detail');
                $return['msg'] = ( $q2 == true ) ? 'success' : 'failed' ;
                $return['url']=site_url('transaksi/faktur/'.$id);
            }else{
                $return['msg']='failed';
            }
            echo json_encode($return,JSON_PRETTY_PRINT);
        } else {
            show_404();
        }
        
    }

// -----------produk keluar detail-----------------------------------------------
    public function keluar_detail($var = null)
    {
        $data['judul'] = 'Detail Product Keluar';
        $data['title'] = 'Detail Product Keluar';

        $this->db->select('id_produk,nama_produk');
        $this->db->where('user_id',$this->session->userdata('logged_in')['id_user']);
        $this->db->where('is_active',1); 
        // Produces: WHERE name = 'Joe'
        $data['list_produk'] = $this->db->get('produk')->result();
		
		$this->template->load('v_detail_keluar',$data);
    }

}

/* End of file Product.php */

?>