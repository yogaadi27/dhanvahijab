<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12">
      <div class="card">
        <!-- <div class="card-header">
          <h5>Inline Form</h5><span>Use<code>.form-inline</code>class in the form to style with inline fields.</span>
        </div> -->
        <div class="card-body">
          <h6>Pilih Produk</h6>
          <form class="form-inline theme-form mt-2" id="add_cart">
            <div class="form-group">
              <label class="col-form-label" for="inputInlineUsername">Produk / Barang</label>
              <select class="form-control form-control-primary btn-square" id="produk_id" name="produk_id" required>
                <option>-- Pilih Product --</option>
                <?php foreach ($list_produk as $key => $value) { ?>
                  <option value="<?=$value->id_produk?>"><?=$value->nama_produk?></option>  
                <?php }?>    
              </select>  
            </div>
              <div class="form-group">
              <label class="col-form-label" for="inputInlinePassword">Harga</label>
              <input class="form-control" id="harga_jual" type="text" name="harga_jual" readonly>
            </div>
            <div class="form-group">
              <label class="col-form-label" for="inputInlinePassword">Stok</label>
              <input class="form-control" id="stok_brg" type="text" name="stok_brg" readonly>
            </div>
            <div class="form-group">
              <label class="col-form-label" for="inputInlinePassword">Tgl</label>
              <input class="datepicker-here form-control digits" value="<?=date('m/d/Y')?>" id="tgl_brg_keluar" name="tgl_brg_keluar" type="text" data-language="en">
            </div>
            <div class="form-group">
              <label class="col-form-label" for="inputInlinePassword">Jumlah</label>
              <input class="form-control" id="qty" type="text" name="qty" placeholder="" autocomplete="off" required>
            </div>
            <!-- <div class="form-group">
              <label class="col-form-label" for="inputInlinePassword">Total</label>
              <input class="form-control" id="inputInlinePassword" type="password" name="inputPassword" placeholder="Password" autocomplete="off">
            </div> -->
            <div class="form-group">
              <button type="submit" class="btn btn-primary">Tambahkan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-header">
          <h5>Cart</h5>
        </div>
        <div class="card-body cart">
          <div class="order-history table-responsive wishlist">
            <table class="table table-bordernone" >
              <thead>
                <tr>
                  <th>Foto</th>
                  <th>Nama Produk</th>
                  <th>Harga ( Rp )</th>
                  <th>Jumlah</th>
                  <th>Aksi</th>
                  <th>Total ( Rp )</th>
                </tr>
              </thead>
              <tbody id="table_cart">
              
              </tbody>
            </table>

            <table class="table table-bordernone" >
              <thead>
                <tr>
                  <hr>
                </tr>
              </thead>
              <form id="form_transaksi">
              <tbody>
                <tr>
                    <td class="total-amount"> 
                        <h6> <span>Tgl transaksi :</span></h6>
                    </td>
                    <td class="total-amount" colspan="3"> 
                        <div class="form-group">
                            <input class="datepicker-here form-control digits" value="<?=date('m/d/Y')?>" id="tgl_transaksi" name="tgl_transaksi" type="text" data-language="en">
                        </div>
                    </td>
                    <td class="total-amount" colspan="1"> 
                        <h6> <span>Jumlah :</span></h6>
                    </td>
                    <td>
                        <div class="form-group">
                            <input class="form-control" id="total_sum" type="text" name="total_sum" readonly>
                        </div>
                    </td>
                </tr>
                <tr>
                   <td class="total-amount"> 
                        <h6> <span>Pembeli :</span></h6>
                    </td>
                    <td class="total-amount" colspan="3"> 
                        <div class="form-group">
                            <input class="form-control" id="nama_distributor" type="text" name="nama_distributor" required>
                        </div>
                    </td>
                    <td class="total-amount" colspan="1"> 
                    <h6> <span>Bayar :</span></h6>
                    </td>
                    <td>
                        <div class="form-group">
                            <input class="form-control" id="bayar" type="number" name="bayar" required>
                        </div>
                    </td>
                </tr>
                <tr>
                   <td class="total-amount"> 
                        <h6> <span>Alamat :</span></h6>
                    </td>
                    <td class="total-amount" colspan="3"> 
                        <div class="form-group">
                            <textarea class="form-control" id="alamat_distributor" type="text" name="alamat_distributor" required></textarea>
                        </div>
                    </td>
                    <td class="total-amount"> 
                    <h6> <span>Jumlah :</span></h6>
                    </td>
                    <td>
                        <div class="form-group">
                            <input class="form-control" id="kembali" type="number" name="kembali" readonly>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="5"></td>
                    <td>
                    <div class="form-group">
                        <button type="submit" name="submit" class="btn btn-primary cart-btn-transform">Simpan Transaksi</button>
                        </div></td>
                </tr>  
              </tbody>
              </form>
            </table>
          </div>
         
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Container-fluid Ends-->


<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>
<script>
  "use strict";
  (function($) {
      "use strict";
  $('#basic-1').DataTable();
  })(jQuery);



  $(document).ready(function() {

   

    get_rincian();

    $('#produk_id').on('change',function (e) {
        e.preventDefault();
        var id_produk = this.value;
      $.ajax({
        method: "POST",
        dataType : 'json',
        data:{id:id_produk},
        url: "<?=base_url('product/get_harga_jual')?>",
      })
      .done(function( data ) {  
          $('#stok_brg').val(data.stok);
          $('#harga_jual').val(data.harga_jual);
      })
      .fail(function(jqXHR,textStatus,error) {
          alert(error);
          console.log
      });
    });

  });

  function formatNumber(num) {
    return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
  }

  /* Fungsi formatRupiah */
  function tambah_qty(id) {
    $.ajax({
        method: "POST",
        url: "<?=site_url('product/tambah_qty') ?>",
        data: { id:id }
      })
        .done(function(data) {
          if (data=='success') {
            get_rincian();
          }else if(data=='empty'){
            $.notify({
                title: "<strong>Gagal !</strong> ",
                message: "Stok Tidak Mencukupi !"

              },{
                  type: 'danger'
              });
          }else{
              $.notify({
              title: "<strong>Error 500 !</strong> ",
              message: "Masalah pada server !"

            },{
                type: 'danger'
            });
          }
            // console.log(data)
           
        });
  }
  
  function minus_qty(id) {
        $.ajax({
            method: "POST",
            url: "<?=site_url('product/minus_qty') ?>",
            data: { id:id }
          })
            .done(function(data) {

              if (data=='success') {
                get_rincian();
              }else if(data=='empty'){
                $.notify({
                    title: "<strong>Sudah Kosong !</strong> ",
                    message: "Harap untuk dihapus !"

                  },{
                      type: 'danger'
                  });
              }else{
                  $.notify({
                  title: "<strong>Error 500 !</strong> ",
                  message: "Masalah pada server !"

                },{
                    type: 'danger'
                });
              }
            });
  }

  function delete_cart(id) {
        $.ajax({
            method: "POST",
            url: "<?=site_url('product/delete_cart') ?>",
            data: { id:id }
          })
            .done(function(data) {

              if (data=='success') {
                $.notify({
                  title: "<strong>Sukses !</strong> ",
                  message: "Berhasil di hapus !"

                },{
                    type: 'info'
                });
              }else{
                $.notify({
                  title: "<strong>Error 500 !</strong> ",
                  message: "Masalah pada server !"

                },{
                    type: 'danger'
                });
              }
                // console.log(data)
                get_rincian();
            
              // swal(
              //     title: 'Kode Bayar Anda : ',
              //   html :  '<div class="alert bg-purple-seance bg-font-purple-seance pulse1"><strong><i class="fa fa-bell"></i> Maaf, Anda harus login dulu! !</strong></div>'
              // ).catch(swal.noop);
            
            });
  }

  function get_rincian() {
    // e.preventDefault();
  
        $.ajax({
          method: "GET",
          dataType:'json',
          url: "<?php echo site_url('product/rincian_cart') ?>",
        })
        .done(function( data ) {    
            // console.log(data);
            $('#table_cart').html(data.rincian);
            $('#total_sum').val(data.total_sum);
            // $('#total_foot').html('Rp. '+data.total_sum);
          
        })
        .fail(function(jqXHR,textStatus,error) {
            alert(error);
            console.log(jqXHR.responseText);
        });
    return false;
}


  $('#add_cart').validator().on('submit', function (e) {
    if (e.isDefaultPrevented()) {
      // handle the invalid form...
      // console.log("gaga");
      $.notify({
          title: '<strong>Gagal !</strong>',
          message: 'Semua Form Wajib di isi !'
      },{
          type: 'danger',
          z_index: 2000,
      });
    } else {

      e.preventDefault();

      var formData = new FormData(this);
    
          $.ajax({
            method: "POST",
            contentType:false,
            catch:false,
            processData:false,
            data:formData,
            url: "<?=site_url('product/add_cart') ?>",
          })
          .done(function(data) {
              // console.log(data);
              if (data=='success') {
              $.notify({
                  title: "<strong>Sukses !</strong> ",
                  message: "Berhasil di tambahkan !"

              },{
                  type: 'success'
              });
              $("#add_cart")[0].reset();
              get_rincian();
              // reload();
              }else{
                  alert('problem in the server');
              }
          });       

    }
  });


  $('#bayar').on('keyup',function () {
      var tot=$('#total_sum').val();
      var bayar=$('#bayar').val();
      // console.log(tot.replace(/,(?=\d*[\.,])/g, "$1"));
      var result=parseFloat(bayar)-parseFloat(tot);
      // console.log(parseFloat(tot));
      if (!isNaN(result)) {
        // console.log(result);
        $('#kembali').val(result);   
      }else{
        $('#kembali').val(result);     
      }
  });

  $('#form_transaksi').validator().on('submit', function (e) {
    
    if (e.isDefaultPrevented()) {
      // handle the invalid form...
      // console.log("gaga");
      $.notify({
          title: '<strong>Gagal !</strong>',
          message: 'Semua Form Wajib di isi !'
      },{
          type: 'danger',
          z_index: 2000,
      });
    } else {

      e.preventDefault();

      var formData = new FormData(this);

      Swal.fire({
      title: 'Anda yakin ingin memproses transaksi ?',
      text: "Pastikan data yang anda masukan benar !",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Ya, Proses !'
      }).then((result) => {
      if (result.isConfirmed) {
      
          $.ajax({
              method: "POST",
              contentType:false,
              catch:false,
              processData:false,
              data:formData,
              dataType:'json',
              url: "<?=site_url('product/add_transaksi') ?>",
              })
              .done(function(data) {
                console.log(data); 
                if (data.msg=='success') {
                  Swal.fire({
                        title: "Transaksi Berhasil...!!",
                        text: "Sukses!",
                        icon: 'success',
                        confirmButtonText:'<i class="fa fa-print"></i> Cetak Nota !',
                    }).then(function() {
                        window.location = data.url;
                    }).catch(swal.noop);
                  // Swal.fire(
                  //     'Berhasil !',
                  //     'Stok Product berhasil disimpan !',
                  //     'success'
                  //     );
                  // $('#modal_add_stock').modal('hide');
                  // $("#form-add-stok")[0].reset();
                  reload();
                  }else{
                      alert('problem in the server');
                  }
              });       

      }
      })
    }
  });

  function reload() {
        $("#table-produk").dataTable().api().ajax.reload( null, false );
  }


</script>