<div class="container-fluid">

<div class="row">
    <!-- Individual column searching (text inputs) Starts-->
    <div class="col-sm-12">
      <div class="card">
          <!-- <div class="card-header">
          <h5>Individual column searching (text inputs) </h5><span>The searching functionality provided by DataTables is useful for quickly search through the information in the table - however the search is global, and you may wish to present controls that search on specific columns.</span>
          </div> -->
          <div class="card-body">
            <!-- Simple demo-->
            <button class="btn btn-primary" type="button" data-toggle="modal" data-original-title="test" data-target="#modal_produk">Tambah Product</button>
            <button class="btn btn-secondary" type="button" data-toggle="modal" data-original-title="test" data-target="#modal_add_stock">Produksi / Pemesanan Kembali</button>
            
                <div class="modal fade bd-example-modal-lg" id="modal_produk" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Form Tambah Produk</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                        </div>
                        <form class="theme-form" id="form-add-produk">
                        <div class="modal-body">
                        
                              <div class="form-group row">
                                <label class="col-sm-3 col-form-label" for="inputEmail3">Nama Produk</label>
                                <div class="col-sm-9">
                                  <input class="form-control" id="nama_produk" name="nama_produk" type="text" placeholder="Nama Produk" required>
                                </div>
                              </div>
                              <div class="form-group row">
                                <label class="col-sm-3 col-form-label" for="inputEmail3">Deskripsi Produk</label>
                                <div class="col-sm-9">
                                  <textarea class="form-control" id="deskripsi_produk" name="deskripsi_produk" type="text" placeholder="Deskripsi Produk" required></textarea>
                                </div>
                              </div>
                              <div class="form-group row">
                                <label class="col-sm-3 col-form-label" for="inputPassword3">Satuan</label>
                                <div class="col-sm-9">
                                  <input class="form-control" id="satuan" name="satuan" type="text" placeholder="Satuan" required>
                                </div>
                              </div>
                              <div class="form-group row">
                                <label class="col-sm-3 col-form-label" for="inputPassword3">Harga Beli</label>
                                <div class="col-sm-9">
                                  <input class="form-control input-harga" id="harga_beli" name="harga_beli" type="number" placeholder="Harga Beli" required>
                                </div>
                              </div>
                              <div class="form-group row">
                                <label class="col-sm-3 col-form-label" for="inputPassword3">Harga Jual</label>
                                <div class="col-sm-9">
                                  <input class="form-control input-harga" id="harga_jual" name="harga_jual" type="number" placeholder="Harga Beli" required>
                                </div>
                              </div>
                              <div class="form-group row">
                                <label class="col-sm-3 col-form-label" for="inputPassword3">Lead Time ( hari )</label>
                                <div class="col-sm-9">
                                  <input class="form-control" id="lead_time" name="lead_time" type="number" placeholder="Lead Time" required>
                                </div>
                              </div>
                              <div class="form-group row">
                                <label class="col-sm-3 col-form-label" for="inputPassword3">Foto Produck ( max : 400 kb ) </label>
                                <div class="col-sm-9">
                                    <div class="file-loading">
                                        <input id="userfile" type="file" name="userfile">
                                    </div>
                                </div>
                              </div>
                        </div>
                        <div class="modal-footer">
                        <button class="btn btn-primary" type="button" data-dismiss="modal">Close</button>
                        <button class="btn btn-secondary" type="submit" name="submit">Save changes</button>
                        </div>
                        </form>
                    </div>
                    </div>
                </div>
            

            <div class="table-responsive product-table">
                <table class="display" id="table-produk">
                <thead>
                    <tr>
                    <th>Foto</th>
                    <th>Nama Produk</th>
                    <th>Harga Beli (Rp)</th>
                    <th>Harga Jual (Rp)</th>
                    <th>Lead Time</th>
                    <th>Stock</th>
                    <th>Status</th>
                    <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
                </table>
            </div>
          </div>
      </div>
    </div>
    <!-- Individual column searching (text inputs) Ends-->
</div>

  <!-- Modal Produksi -->
  <div class="modal fade" id="modal_add_stock" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Form Produksi / Pemesanan Kembali</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <form class="theme-form" id="form-add-stok">
            <div class="modal-body">
            <div class="col-md-12">
              <div class="col-form-label">Pilih Product</div>
              <select class="form-control form-control-primary btn-square" id="produk_id" name="produk_id" required>
              <option>-- Pilih Product --</option>  
                <?php foreach ($list_produk as $key => $value) { ?>
                  <option value="<?=$value->id_produk?>"><?=$value->nama_produk?></option>  
                <?php }?>
              </select>  
            </div>
            <div class="col-md-12">
              <div class="col-form-label">Tgl Produksi</div>
              <input class="datepicker-here form-control digits" id="tgl_produksi" name="tgl_produksi" type="text"  data-language="en">
            </div>
            <div class="col-md-12">
              <div class="col-form-label">Harga Beli</div>
                <input class="form-control" id="hrg_beli" type="number" name="hrg_beli" readonly>
            </div>
            <div class="col-md-12">
              <div class="col-form-label">Jumlah Produksi/stock</div>
                <input class="form-control" id="stok" type="number" name="stok" placeholder="Masukan jumlah produksi/stock" required>
            </div>
            <div class="col-md-12">
              <div class="col-form-label">Biaya Produksi</div>
                <input class="form-control" id="biaya_produksi" type="number" name="biaya_produksi" readonly>
            </div>
      
            <div class="modal-footer">
            <button class="btn btn-primary" type="button" data-dismiss="modal">Tutup</button>
            <button class="btn btn-secondary" type="submit" name="submit">Tambahkan</button>
            </div>
            </form>
        </div>
      </div>
  </div>
</div>




<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>
<script>
  "use strict";
  (function($) {
      "use strict";
  $('#basic-1').DataTable();
  })(jQuery);



  $(document).ready(function() {

    $('#produk_id').on('change',function (e) {
        e.preventDefault();
        var id_produk = this.value;
      $.ajax({
        method: "POST",
        dataType : 'json',
        data:{id:id_produk},
        url: "<?=base_url('product/get_harga')?>",
      })
      .done(function( data ) {    
          $('#hrg_beli').val(data.harga_beli);
      })
      .fail(function(jqXHR,textStatus,error) {
          alert(error);
          console.log
      });
    });

    $('#stok').on('keyup',function (e) {
        e.preventDefault();
        var stok = this.value;
        var hrg_beli = $('#hrg_beli').val();
        $('#biaya_produksi').val(stok*hrg_beli);

    });

      $("#userfile").fileinput({
          browseClass: "btn btn-primary btn-block",
          allowedFileExtensions: ["jpeg", "png", "jpg"],
          showCaption: false,
          showRemove: false,
          showUpload: false,
          maxFileSize: 400,

      });

      var table;
      //datatables
      table = $('#table-produk').DataTable({ 

          "processing": true, 
          "serverSide": true, 
          "order": [], 
      
          "ajax": {
              "url": "<?php echo site_url('product/ajax_list_produk')?>",
              "type": "POST",
            
          },
          
          "dom": 'lBfrtip',
          "pageLength": 10, 
          buttons: [
              'copyHtml5',
              'excelHtml5',
              'csvHtml5',
              'pdfHtml5'
          ]
      });

  });


  $('#form-add-produk').validator().on('submit', function (e) {
    if (e.isDefaultPrevented()) {
      // handle the invalid form...
      // console.log("gaga");
      $.notify({
          title: '<strong>Gagal !</strong>',
          message: 'Semua Form Wajib di isi !'
      },{
          type: 'danger',
          z_index: 2000,
      });
    } else {

      e.preventDefault();

      var formData = new FormData(this);

      Swal.fire({
      title: 'Anda yakin ingin menambah produk ?',
      text: "Pastikan data yang anda masukan benar !",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Simpan !'
      }).then((result) => {
      if (result.isConfirmed) {
      
          $.ajax({
              method: "POST",
              contentType:false,
              catch:false,
              processData:false,
              data:formData,
              url: "<?=site_url('product/add_product') ?>",
              })
              .done(function(data) {
                  if (data=='success') {
                  Swal.fire(
                      'Berhasil !',
                      'Product berhasil disimpan !',
                      'success'
                      );
                  $('#modal_produk').modal('hide');
                  $("#form-add-produk")[0].reset();
                  reload();
                  }else{
                      alert('problem in the server');
                  }
              });       

      }
      })
    }
  });

  $('#form-add-stok').validator().on('submit', function (e) {
    if (e.isDefaultPrevented()) {
      // handle the invalid form...
      // console.log("gaga");
      $.notify({
          title: '<strong>Gagal !</strong>',
          message: 'Semua Form Wajib di isi !'
      },{
          type: 'danger',
          z_index: 2000,
      });
    } else {

      e.preventDefault();

      var formData = new FormData(this);

      Swal.fire({
      title: 'Anda yakin ingin menambah stock produk ?',
      text: "Pastikan data yang anda masukan benar !",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Ya, Tambahkan !'
      }).then((result) => {
      if (result.isConfirmed) {
      
          $.ajax({
              method: "POST",
              contentType:false,
              catch:false,
              processData:false,
              data:formData,
              url: "<?=site_url('product/add_stock') ?>",
              })
              .done(function(data) {
                // console.log(data); 
                if (data=='success') {
                  Swal.fire(
                      'Berhasil !',
                      'Stok Product berhasil disimpan !',
                      'success'
                      );
                  $('#modal_add_stock').modal('hide');
                  $("#form-add-stok")[0].reset();
                  reload();
                  }else{
                      alert('problem in the server');
                  }
              });       

      }
      })
    }
  });

  function reload() {
        $("#table-produk").dataTable().api().ajax.reload( null, false );
  }
  
</script>