<div class="container-fluid">

<div class="row">
    <!-- Individual column searching (text inputs) Starts-->
    <div class="col-sm-12">
      <div class="card">
          <div class="card-header">
          <h5>Riwayat transaksi keluar</h5>
          </div>
          <div class="card-body">
            <!-- Simple demo-->
            <!-- <button class="btn btn-primary" type="button" data-toggle="modal" data-original-title="test" data-target="#modal_produk">Tambah Product</button>
            <button class="btn btn-secondary" type="button" data-toggle="modal" data-original-title="test" data-target="#modal_add_stock">Tambah Stock</button> -->
          
            <div class="table-responsive product-table">
                <table class="display" id="table_transaksi">
                <thead>
                    <tr>
                    <th>Tgl Transaksi</th>
                    <th>Distributor</th>
                    <th>Total Bayar</th>
                    <th></th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
                </table>
            </div>
          </div>
      </div>
    </div>
    <!-- Individual column searching (text inputs) Ends-->
</div>

</div>




<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>

<script>
  
  $(document).ready(function() {

     

      var table2;
      //datatables per produk
      table2 = $('#table_transaksi').DataTable({ 

          "processing": true, 
          "serverSide": true, 
          "order": [], 
      
          "ajax": {
              "url": "<?php echo site_url('transaksi/ajax_list_detail_transaksi')?>",
              "type": "POST",
          },
          "dom": 'lBfrtip',
          "pageLength": 10, 
          buttons: [
              'copyHtml5',
              'excelHtml5',
              'csvHtml5',
              'pdfHtml5'
          ]
      });

  });

  function reload() {
        $("#table-produk").dataTable().api().ajax.reload( null, false );
  }

</script>