<!-- <script src="<?=base_url()?>/assets/print/print.min.css"></script> -->
<div class="container-fluid" >

<div class="row" >
    <div class="col-sm-12">
        <div class="card">
            <div class="card-body">
            <div class="invoice" id="renderPDF">
                <div>
                    <div>
                        <div class="row">
                        <div class="col-sm-12">
                            <div class="media">
                                <div class="media-left"><img class="media-object img-60" src="<?=base_url()?>/assets/images/other-images/logo-login.png" alt=""></div>
                                <div class="media-body m-l-20">
                                <h4 class="media-heading">Faktur #<span class="digits counter"><?=date("ymd",strtotime($data->row()->tgl_transaksi,TRUE)).$data->row()->id_produk_keluar.$data->row()->user_id;?></span></h4>
                                <p>Tanggal transaksi : <span class="digits"><?=$data->row()->tgl_transaksi?></span></p>
                                </div>
                            </div>
                        </div>
                              
                        </div>
                        <hr>
                        <!-- End InvoiceTop-->
                        <div class="row">
                            <div class="col-md-12">
                       
                            <table class="table table-bordered table-striped">
                                    <tbody>
                                    <tr>
                                    <div class="col-md-6">
                                        <td class="item">
                                            
                                                <div class="media">
                                                        <div class="media-body m-l-20">
                                                        <h6 class="media-heading">Dari :</h6>
                                                        <h4 class="media-heading"><?=$this->session->userdata('logged_in')['fullname']?></h4>
                                                        <p><?=$this->session->userdata('logged_in')['alamat']?><br><span class="digits">555-555-5555</span></p>
                                                        </div>
                                                </div>
                                            
                                        </td>
                                        </div>
                                        <div class="col-md-6">
                                        <td class="Hours">
                                            
                                                <div class="media">
                                                    <div class="media-body m-l-20">
                                                        <h6 class="media-heading">Kepada :</h6>
                                                        <h4 class="media-heading"><?=$data->row()->nama_distributor?></h4>
                                                        <p><?=$data->row()->alamat_distributor?><br><span class="digits">555-555-5555</span></p>
                                                    </div>
                                                </div>
                                            
                                        </td>
                                        </div>
                                    </tr>
                                    </tbody>
                            </table>
                            </div>
                        </div>

                        <div class="row">
                          <hr>
                        </div>
                        <!-- End Invoice Mid-->
                        <div>
                            <div class="table-responsive invoice-table" id="table">
                            <table class="table table-bordered table-striped">
                                <tbody>
                                <tr>
                                    <td class="item">
                                    <h6 class="p-2 mb-0">Item Description</h6>
                                    </td>
                                    <td class="Hours">
                                    <h6 class="p-2 mb-0">Qty</h6>
                                    </td>
                                    <td class="Rate">
                                    <h6 class="p-2 mb-0">Harga</h6>
                                    </td>
                                    <td class="subtotal">
                                    <h6 class="p-2 mb-0">Total</h6>
                                    </td>
                                </tr>
                                <?php 
                                foreach ($rincian as $key => $value) { ?>
                                    <tr>
                                        <td>
                                        <label><?=$value->nama_produk ?></label>
                                        </td>
                                        <td>
                                        <p class="itemtext digits"><?=$value->qty.' '.$value->satuan ?></p>
                                        </td>
                                        <td>
                                        <p class="itemtext digits"><?=number_format($value->harga_jual) ?></p>
                                        </td>
                                        <td>
                                        <p class="itemtext digits"><?=number_format($value->total_biaya) ?></p>
                                        </td>
                                    </tr>
                                <?php } ?>
                                <tr>
                                    <td colspan="2"><i><strong>Terbilang : </strong> <?=terbilang($data->row()->total_bayar)?></i></td>
                                    <td class="Rate">
                                    <h6 class="mb-0 p-2">Jumlah Total</h6>
                                    </td>
                                    <td class="payment digits">
                                    <h6 class="mb-0 p-2"><?=number_format($data->row()->total_bayar)?></h6>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2"></td>
                                    <td class="Rate">
                                    <h6 class="mb-0 p-2">Bayar</h6>
                                    </td>
                                    <td class="payment digits">
                                    <h6 class="mb-0 p-2"><?=number_format($data->row()->bayar)?></h6>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2"></td>
                                    <td class="Rate">
                                    <h6 class="mb-0 p-2">Kembali</h6>
                                    </td>
                                    <td class="payment digits">
                                    <h6 class="mb-0 p-2"><?=number_format($data->row()->kembali)?></h6>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                            </div>
                            <!-- End Table-->
                            <!-- <div class="row">
                                <div class="col-md-12">
                                    <div>
                                    <p class="legal"><strong>Thank you for your business!</strong></p>
                                    </div>
                                </div>
                            </div> -->
                            <div class="row">
                                <div class="col-md-12">
                        
                                <table class="table">
                                        <tbody>
                                        <tr>
                                            <td>
                                            <div class="col-md-4 offset-2">
                                                <div>
                                                <p class="legal"><strong>Tanda Terima,<br><?=$data->row()->nama_distributor?>
                                                </p></strong>
                                                <p>&nbsp;</p>
                                                <p>&nbsp;</p>
                                                <p>( ........................... )</p>
                                                </div>
                                            </div>
                                            </td>
                                            <td class="Hours">
                                                <div class="col-md-4 offset-2">
                                                    <div>
                                                    <p class="legal"><strong>Hormat Kami,<br><?=$this->session->userdata('logged_in')['fullname']?></strong>
                                                    </p>
                                                    <p>&nbsp;</p>
                                                    <p>&nbsp;</p>
                                                    <p>( ............................ )</p>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        </tbody>
                                </table>
                                </div>
                            </div>
                        </div>
                        <!-- End InvoiceBot-->
                    </div>
                       
                    <!-- End Invoice-->
                    <!-- End Invoice Holder-->
                </div>
            </div>
            <div class="col-sm-12 text-center mt-3">

                        <button class="btn btn btn-primary mr-2" type="button" id="print">Print</button>
                        <a href="<?=site_url('transaksi');?>" class="btn btn-secondary" type="button">Kembali</a>
            
            </div>
        </div>
    </div>
</div>


</div>


<!-- <script src="<?=base_url()?>/assets/print/html2canvas.min.js"></script> -->
<script src="<?=base_url()?>/assets/print/printThis.js"></script>
<!-- <script type="text/javascript" src="https://github.com/MrRio/jsPDF/blob/master/libs/html2canvas/dist/html2canvas.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.2/jspdf.debug.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>

<script language="javascript">
  $('#print').on("click", function () {
      $('#renderPDF').printThis({
        debug: false,
        importStyle: true,
        removeInline :false ,         // hapus gaya sebaris dari elemen cetak 
        removeInlineSelector : "" ,   // pemilih khusus untuk memfilter gaya sebaris. removeInline harus benar 

        });
    });
</script>