<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        $this->load->model('Model_transaksi_keluar','m_transaksi_keluar');
        $this->load->model('Model_transaksi_detail','m_transaksi');
        is_logged_in();

    }

    public function index()
    {
        $data['judul'] = 'Transaksi Product Keluar';
        $data['title'] = 'Transaksi Product Keluar';

        // $this->db->select('id_produk,nama_produk');
        // $this->db->where('user_id',$this->session->userdata('logged_in')['id_user']);
        // $this->db->where('is_active',1); 
        // // Produces: WHERE name = 'Joe'
        // $data['list_produk'] = $this->db->get('produk')->result();
		
		$this->template->load('v_transaksi_keluar',$data);
    }

    public function ajax_list_produk_keluar()
    {
          if ($this->input->is_ajax_request()) {
                # code...
                $status='';
                $list = $this->m_transaksi_keluar->get_datatables();
                $data = array();
                $no = $_POST['start'];
                $total_sum=0;

                // print_r($list);
                // die();
                foreach ($list as $l) {
                    $no++;

                    $total=$l->qty*$l->harga_jual;
                    $total_sum+=$total;

                    $row = array();
                    
                      $row[] = '<img src="'.base_url('/uploads/product/'.$l->foto).'" width="64" height="64" alt="">';
                      $row[] = '<h6>'.$l->nama_produk.'</h6><span>'.$l->deskripsi_produk.'</span>';
                      $row[] = $l->jumlah_keluar.' '.$l->satuan;
                      $row[] = $l->is_active == 1 ? '<span class="badge badge-primary">aktif</span>' : '<span class="badge badge-danger">nonaktif</span>';
                      $row[] = number_format($total_sum,0);
                      $data[] = $row;
                }
    
                $output = array(
                                "draw" => $_POST['draw'],
                                "recordsTotal" => $this->m_transaksi_keluar->count_all(),
                                "recordsFiltered" => $this->m_transaksi_keluar->count_filtered(),
                                "data" => $data,
                        );
                //output to json format
    
                echo json_encode($output);
          }else{
              show_404();
          }
            
    }

    public function ajax_list_detail_transaksi()
    {
          if ($this->input->is_ajax_request()) {
                # code...
                $status='';
                $list = $this->m_transaksi->get_datatables();
                $data = array();
                $no = $_POST['start'];
                
                foreach ($list as $l) {
                    $no++;
  
                    $row = array();
                    // $row[] = $no;
                    // $row[] = '<img src="'.base_url('/uploads/product/'.$l->foto).'" width="64" height="64" alt="">';
                    $row[] = $l->tgl_transaksi;
                    $row[] = '<h6>'.$l->nama_distributor.'</h6><span>'.$l->alamat_distributor.'</span>';
                    $row[] = number_format($l->total_bayar,0);
                    $row[] = '
                            <a href="'.site_url('transaksi/faktur/'.$l->id_produk_keluar).'" class="btn btn-success" type="button" data-original-title="btn btn-danger btn-xs" title=""><i class="fa fa-print"></i> Cetak Faktur</a>
                            ';	 
                    $data[] = $row;
                }
    
                $output = array(
                                "draw" => $_POST['draw'],
                                "recordsTotal" => $this->m_transaksi->count_all(),
                                "recordsFiltered" => $this->m_transaksi->count_filtered(),
                                "data" => $data,
                        );
                //output to json format
                echo json_encode($output);
          }else{
              show_404();
          }
            
    }
    
    public function faktur($id = null)
    {
        if (!is_null($id)) {
            $data['judul'] = 'Faktur';
            $data['title'] = 'Faktur';

            $this->db->select('nama_produk, deskripsi_produk, satuan, produk_keluar_detail.harga_jual, qty, total_biaya');
            $this->db->from('produk_keluar_detail');
            $this->db->join('produk', 'produk.id_produk = produk_keluar_detail.produk_id');
            $this->db->where('produk_keluar_id',$id);
            $data['rincian'] = $this->db->get()->result();  
            $data['data'] = $this->db->get_where('produk_keluar', array('id_produk_keluar' => $id),1);
            if ($data['data']->num_rows() != 0) {
                $this->template->load('v_faktur',$data);
            }else{
                show_404();
            }
        }else{
            show_404();
        }
    }

}

/* End of file Transaksi.php */

?>