<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Analisa extends CI_Controller {

    
    public function __construct()
    {
        parent::__construct();
        //Do your magic here
        is_logged_in();
        $this->load->model('biaya/Model_penyimpanan','m_penyimpanan');
        $this->load->model('biaya/Model_pemesanan','m_pemesanan');
    }
    

    public function index(Type $var = null)
    {
        # code...
        $this->db->select('id_produk,nama_produk');
        $this->db->where('user_id',$this->session->userdata('logged_in')['id_user']);
        $this->db->where('is_active',1);
        $data['list_produk'] = $this->db->get('produk')->result();

        // $data['rincian']=$html;
        $data['judul'] = 'Analisa Metode EOQ';
        $data['title'] = 'Analisa Metode EOQ';
		$this->template->load('v_analisa_product',$data);
    }

    public function index_x()
    {

        // $this->db->select('*');
        // $this->db->from('produk');
        // $this->db->where('user_id',$this->session->userdata('logged_in')['id_user']);
        // $q=$this->db->get();

        // $html='';
        // foreach ($q->result() as $l) {

        //     // query get biaya pesan
        //     $this->db->select('SUM(jumlah_biaya_pesan) AS biaya_pemesanan', FALSE);
        //     $this->db->from('biaya_pemesanan');
        //     $this->db->where('produk_id',$l->id_produk);
        //     $this->db->group_by('produk_id');
        //     $q=$this->db->get();
        //     $b_pesan = ($q->num_rows() > 0 ) ? $q->row()->biaya_pemesanan : 0 ;

        //     // query get biaya simpan
        //     $this->db->select('SUM(jumlah_biaya_simpan) AS biaya_penyimpanan', FALSE);
        //     $this->db->from('biaya_penyimpanan');
        //     $this->db->where('produk_id',$l->id_produk);
        //     $this->db->group_by('produk_id');
        //     $q=$this->db->get();
        //     $b_simpan = ($q->num_rows() > 0 ) ? $q->row()->biaya_penyimpanan : 0 ;
        //     // print_r($query);

        //     $html.='<tr>
        //             <td>
        //                 <img src="'.base_url('/uploads/product/'.$l->foto).'" width="64" height="64" alt="">
        //             </td>';
        //     $html.='<td><div class="product-name">'.$l->nama_produk.'</div></td>';
        //     $html.='<td>'.number_format($b_pesan,0).'</td>';
        //     $html.='<td>'.number_format($b_simpan,0).'</td>';
        //     $html.= $l->is_active == 1 ? '<td><span class="badge badge-primary">aktif</span></td>' : '<td><span class="badge badge-danger">nonaktif</span></td>';
        //     $html.='<td>
        //                 <a href="javascript:void(0)" onclick="cetak_eoq(\''.$l->id_produk.'\')" class="btn btn-success" type="button">Lihat Detail</a>
        //             </td>
        //             </tr>';
        // }
          
        // $data['rincian']=$html;
        // $data['judul'] = 'Analisa Metode EOQ';
		// $data['title'] = 'Analisa Metode EOQ';
		
		// $this->template->load('v_analisa',$data);
    }

    public function cetak(Type $var = null)
    {
        $data['judul'] = 'Hasil Analisa Metode EOQ';
        $data['title'] = 'Hasil Analisa Metode EOQ';
        $data['periode'] = $this->input->get('periode');
        $data['produk'] = $this->input->get('produk');
        $data['rata2'] = $this->input->get('average');
        $data['biaya_pemesanan'] = number_format($this->input->get('bpesan'),0);
        $data['biaya_penyimpanan'] = number_format($this->input->get('bsimpan'),0);
        $data['eoq'] = number_format($this->input->get('eoq'),0);
        $data['ss'] = $this->input->get('ss');
        $data['mi'] = $this->input->get('mi');
        $data['rop'] = $this->input->get('rop');

        // echo $tahun.$produk;
        // print_r($this->input->get());
		$this->template->load('v_cetak_analisa',$data);

    }

    public function product($var = null)
    {
        $this->db->select('id_produk,nama_produk');
        $this->db->where('user_id',$this->session->userdata('logged_in')['id_user']);
        $this->db->where('is_active',1);
        $data['list_produk'] = $this->db->get('produk')->result();

        // $data['rincian']=$html;
        $data['judul'] = 'Analisa Metode EOQ';
        $data['title'] = 'Analisa Metode EOQ';
		$this->template->load('v_analisa_product',$data);
        
    }

    public function get_data_jual($var = null)
    {
        # code...
        if ($this->input->is_ajax_request()) {
            # code...
            $bulan=array (
                1 => 'Januari',
                2 => 'Februari',
                3 => 'Maret',
                4 => 'April',
                5 => 'Mei',
                6 => 'Juni',
                7 => 'Juli',
                8 => 'Agustus',
                9 => 'September',
                10 => 'Oktober',
                11 => 'November',
                12 => 'Desember'
            );
            $rt=0;

            //cari biaya pesan
            $this->db->select('SUM(jumlah_biaya_pesan) AS biaya_pemesanan', FALSE);
            $this->db->from('biaya_pemesanan');
            $this->db->join('produk','produk.id_produk=biaya_pemesanan.produk_id');
            $this->db->group_by('produk_id');
            $this->db->where('produk.user_id',$this->session->userdata('logged_in')['id_user']);
            $biaya_pemesanan=$this->db->get()->row()->biaya_pemesanan;
            
            //cari biaya penyimpanan
            $this->db->select('SUM(jumlah_biaya_simpan) AS biaya_penyimpanan', FALSE);
            $this->db->from('biaya_penyimpanan');
            $this->db->join('produk','produk.id_produk=biaya_penyimpanan.produk_id');
            $this->db->group_by('produk_id');
            $this->db->where('produk.user_id',$this->session->userdata('logged_in')['id_user']);
            $biaya_penyimpanan=$this->db->get()->row()->biaya_penyimpanan;
            
            //
            $this->db->select('nama_produk,leadtime');
            $this->db->where('id_produk',$this->input->post('produk_id',TRUE));
            $dt_produk = $this->db->get('produk')->row();
            $leadtime = $dt_produk->leadtime;
            $produk = $dt_produk->nama_produk;



            $highest = 0;
            $html='';
            $sisa=0;
            foreach ($bulan as $key => $value) {
                //penjualan
                $this->db->select('leadtime,tgl_brg_keluar,nama_produk, SUM(qty) AS jumlah_qty', FALSE);
                $this->db->from('produk_keluar_detail');
                $this->db->join('produk','produk.id_produk=produk_keluar_detail.produk_id');
                $this->db->where('produk_id',$this->input->post('produk_id',TRUE));
                $this->db->where('produk.user_id',$this->session->userdata('logged_in')['id_user']);
                $this->db->where('YEAR(tgl_brg_keluar)',$this->input->post('yearpicker'));
                $this->db->where('MONTH(tgl_brg_keluar)',$key);
                $this->db->group_by('MONTH(tgl_brg_keluar), YEAR(tgl_brg_keluar)');
                $q=$this->db->get();
                $terjual = ($q->num_rows() >0 ) ? $q->row()->jumlah_qty : 0 ;
                //pomesanan
                $this->db->select('tgl_masuk,nama_produk, SUM(jumlah_masuk) AS qty_in', FALSE);
                $this->db->from('produk_masuk');
                $this->db->join('produk','produk.id_produk=produk_masuk.produk_id');
                $this->db->where('produk_id',$this->input->post('produk_id',TRUE));
                $this->db->where('produk.user_id',$this->session->userdata('logged_in')['id_user']);
                $this->db->where('YEAR(tgl_masuk)',$this->input->post('yearpicker'));
                $this->db->where('MONTH(tgl_masuk)',$key);
                $this->db->group_by('MONTH(tgl_masuk), YEAR(tgl_masuk)');
                $q2=$this->db->get();
                $memesan=($q2->num_rows() >0 ) ? $q2->row()->qty_in : 0 ;
                
                //saldo be4jalan
                $sisa+=$memesan-$terjual;

                $ret = ($q->num_rows() >0 ) ? $q->row()->jumlah_qty : 0 ;
                
                // echo $value." : ".$ret."<br>";
                $rt += number_format($ret);
                $rata2=number_format($rt/$key,0);

                //menghitung eoq
                $eoq=sqrt((2*$biaya_pemesanan*$rata2)/$biaya_penyimpanan);

                //menghitung Safety Stok
                if($rata2 > $highest) {
                    $highest = $rata2;
                }
                $ss=($highest-$rata2)*($leadtime/30);
                $mi=number_format($eoq+$ss,0);
                $rop=number_format(($leadtime/30)*$rata2+$ss);

                $html.='  <tr>
                            <th scope="row">'.$key.'</th>
                            <td>'.$value.'</td>
                            <td>'.$memesan.'</td>
                            <td>'.$terjual.'</td>
                            <td>'.$sisa.'</td>
                            <td>'.$rata2.'</td>
                            <td>'.number_format($biaya_pemesanan,0).'</td>
                            <td>'.number_format($biaya_penyimpanan,0).'</td>
                            <td>'.number_format($eoq,0).'</td>
                            <td>'.$ss.'</td>
                            <td>'.$rop.'</td>
                            <td>'.$mi.'</td>
                            <td><a href="'.site_url('analisa/cetak?produk='.$produk).'&periode='.$value.' '.$this->input->post('yearpicker').'&rop='.$rop.'&average='.$rata2.'&bpesan='.$biaya_pemesanan.'&bsimpan='.$biaya_penyimpanan.'&eoq='.$eoq.'&ss='.$ss.'&mi='.$mi.'" class="btn btn-success btn-sm">Lihat Detail</a>
                            </td>  
                            </tr>';
            }

            $data['table']=$html;
            $data['msg']='success';
            $data['title']='<h4>Analisa Metode EOQ Tahun '.$this->input->post('yearpicker').'</h4><br>Pada Produk : '.$produk;
            // print_r($this->input->post());
            echo json_encode($data,JSON_PRETTY_PRINT);
        } else {
            # code...
            show_404();
        }
        
    }

}

/* End of file Analisa.php */

?>