<div class="container-fluid">
  <div class="row">
      <!-- Individual column searching (text inputs) Starts-->
      <div class="col-sm-12">
        <div class="card">
            <div class="card-body">
              
              <div class="table-responsive product-table">
                  <table class="display" id="table-pemesanan">
                  <thead>
                      <tr>
                      <th>Foto</th>
                      <th>Nama Produk</th>
                      <th>Biaya Pemesanan</th>
                      <th>Biaya Penyimpanan</th>
                      <th>Status</th>
                      <th>Aksi</th>
                      </tr>
                  </thead>
                  <tbody>
                  <?=$rincian?>
                  </tbody>
                  </table>
              </div>
            </div>
        </div>
      </div>
      <!-- Individual column searching (text inputs) Ends-->
  </div>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>
<script>

  $(document).ready(function() {
    var table;
      //datatables
      table = $('#table-pemesanan').DataTable();
  });

</script>