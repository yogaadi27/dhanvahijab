<!-- <script src="<?=base_url()?>/assets/print/print.min.css"></script> -->
<div class="container-fluid" >

<div class="row" >
    <div class="col-sm-12">
        <div class="card">
            <div class="card-body">
            <div class="invoice" id="renderPDF">
                <div>
                    <div>
                        <div class="row">
                        <div class="col-sm-12">
                            <div class="media">
                                <div class="media-left"><img class="media-object img-60" src="<?=base_url()?>/assets/images/other-images/logo-login.png" alt=""></div>
                                <div class="media-body m-l-20">
                                <h4 class="media-heading">Hasil Analisa Persediaan Produk dengan Metode EOQ</h4>
                                <p><h5 class="txt-danger">Nama Produk : <?=$produk?>| Data Per Akhir Bulan : <?=$periode?></span></h5></p>
                                </div>
                            </div>
                        </div>
                              
                        </div>
                        <hr>
                        <!-- End InvoiceTop-->
                        <div class="row">
                          <hr>
                        </div>
                        <!-- End Invoice Mid-->
                        <div>
                            <div class="table-responsive invoice-table" id="table">
                            <table class="table table-bordered table-striped">
                                <thead class="thead-dark">
                                    <tr>
                                    <th scope="col" class="item"> <h6 class="p-2 mb-0">Deskripsi</h6></th>
                                    <th scope="col"><h6 class="p-2 mb-0">Keterangan</h6></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>
                                        <label><strong>Biaya Pemesanan</strong></label>
                                        <p class="m-0"><i>Penjelasan : Biaya dari persiapan pemesanan sampai barang yang dipesan datang</i></p>
                                    </td>
                                    <td>
                                        <p class="itemtext digits"><?=$biaya_pemesanan?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label><strong>Biaya Penyimpanan</strong></label>
                                        <p class="m-0"><i>Penjelasan : Biaya yang dibutuhkan penyimpanan produk di Gudang (Inventory Carrying Cost)</i></p>
                                    </td>
                                    <td>
                                        <p class="itemtext digits"><?=$biaya_penyimpanan?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label><strong>Penjualan Rata-rata</strong></label>
                                        <p class="m-0"><i>Penejelasan : Penjualan Rata-rata per akhir bulan <?=$periode?></i></p>
                                    </td>
                                    <td>
                                        <p class="itemtext digits"><?=$rata2?> produk</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label><strong>Jumlah Pemesanan Ekonomisnya ( EOQ )</strong></label>
                                        <p class="m-0"><i>Penjelasan : Jumlah pemesananan optimum untuk setiap kali pemesanan kembali / produksi</i></p>
                                    </td>
                                    <td>
                                        <p class="itemtext digits"><?=$eoq?> produk</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label><strong>Persediaan Pengaman ( Safety Stock )</strong></label>
                                        <p class="m-0"><i>Penjelasan : Persediaan tambahan yang diadakan untuk menjaga kemungkinan terjadinya kekurangan persediaan (stock out).</i></p>
                                    </td>
                                    <td>
                                        <p class="itemtext digits"><?=$ss?> produk</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label><strong>Reorder Point ( ROP )</strong></label>
                                        <p class="m-0"><i>Penjelasan : Waktu pemesanan atau produksi kembali produk jika stok mencapai <?=$rop;?> produk</i></p>
                                    </td>
                                    <td>
                                        <p class="itemtext digits"><?=$rop?> produk</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label><strong>Persediaan Maksimum ( Maksimum Inventory / MI )</strong></label>
                                        <p class="m-0"><i>Penjelasan : Persediaan produk yang boleh disimpan didalam gudang</i></p>
                                    </td>
                                    <td>
                                        <p class="itemtext digits"><?=$mi?> produk</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <div class="alert alert-warning inverse fade show" role="alert"><i class="icon-bell"></i>
                                            <p><b> Hasil Analisa ini digunakan sebagai acuan untuk Periode / Bulan Berikutnya ! </b></p>
                                        </div>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                            </div>
                            <!-- End Table-->
                            <!-- <div class="row">
                                <div class="col-md-12">
                                    <div>
                                    <p class="legal"><strong>Thank you for your business!</strong></p>
                                    </div>
                                </div>
                            </div> -->
                        </div>
                        <!-- End InvoiceBot-->
                    </div>
                       
                    <!-- End Invoice-->
                    <!-- End Invoice Holder-->
                </div>
            </div>
            <div class="col-sm-12 text-center mt-3">

                        <button class="btn btn btn-primary mr-2" type="button" id="print">Print</button>
                        <a href="<?=site_url('analisa');?>" class="btn btn-secondary" type="button">Kembali</a>
            
            </div>
        </div>
    </div>
</div>


</div>


<!-- <script src="<?=base_url()?>/assets/print/html2canvas.min.js"></script> -->
<script src="<?=base_url()?>/assets/print/printThis.js"></script>
<!-- <script type="text/javascript" src="https://github.com/MrRio/jsPDF/blob/master/libs/html2canvas/dist/html2canvas.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.2/jspdf.debug.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>

<script language="javascript">
  $('#print').on("click", function () {
      $('#renderPDF').printThis({
        debug: false,
        importStyle: true,
        removeInline :false ,         // hapus gaya sebaris dari elemen cetak 
        removeInlineSelector : "" ,   // pemilih khusus untuk memfilter gaya sebaris. removeInline harus benar 

        });
    });
</script>