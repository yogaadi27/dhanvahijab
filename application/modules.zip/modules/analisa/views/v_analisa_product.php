
<link href="<?=base_url()?>/assets/css/morris.css" rel="stylesheet"/>
<!-- Year Picker CSS -->
<link rel="stylesheet" href="<?=base_url()?>/assets/plugins/year-picker/css/yearpicker.css" />


<div class="container-fluid">
    <!-- <div class="select2-drpdwn"> -->
        <div class="row">
            <!-- Default Textbox start-->
            <!-- Default Textbox end-->
            <!-- Input Groups start-->
            <div class="col-sm-3">
                <div class="card">
                    <div class="card-body">
                    <form id="form-year">
                        <div class="form-group m-form__group">
                            <label>Pilih Tahun</label>
                            <div class="input-group mb-3">
                            <div class="input-group-prepend"><span class="input-group-text"><i class="fa fa-calendar"></i></span></div>
                                <input class="form-control" type="text" name="yearpicker" id="yearpicker" placeholder="">
                            </div>
                        </div>
                        <div class="form-group">
                        <label class="col-form-label" for="inputInlineUsername">Produk / Barang</label>
                        <select class="form-control form-control-primary btn-square" id="produk_id" name="produk_id" required>
                            <option>-- Pilih Product --</option>
                            <?php foreach ($list_produk as $key => $value) { ?>
                            <option value="<?=$value->id_produk?>"><?=$value->nama_produk?></option>  
                            <?php }?>    
                        </select>  
                        </div>
                        <button class="btn btn-primary" type="submit"><i class="fa fa-send"></i>  Tampilkan</button>
                    </form>
                    </div>
                </div>
            </div>
            <!-- Input Groups end-->
        </div>
    <!-- </div> -->

    <div class="row">
            <!-- Default Textbox start-->
            <!-- Default Textbox end-->
            <!-- Input Groups start-->
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header text-center">
                    <h5 id="title"></h5>
                    </div>
                    <div class="card-body">
                    <div class="table-responsive">
                            <table class="table">
                                <thead class="thead-dark">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Bulan</th>
                                    <th scope="col">Produk Masuk</th>
                                    <th scope="col">Produk Keluar</th>
                                    <th scope="col">Sisa Stok</th>
                                    <th scope="col">Rata2 Penjualan</th>
                                    <th scope="col">Biaya Pemesanan</th>
                                    <th scope="col">Biaya Penyimpanan</th>
                                    <th scope="col">EOQ</th>
                                    <th scope="col">Safety Stok</th>
                                    <th scope="col">ROP</th>
                                    <th scope="col">MI</th>
                                    <th scope="col"></th>
                                </tr>
                                </thead>
                                <tbody id="tabel">
                                </tbody>
                            </table>
                            </div>
                    </div>
                </div>
            </div>
            <!-- Input Groups end-->
    </div>
</div>
          <!-- Container-fluid Ends-->


<script src="<?=base_url()?>/assets/js/chart/morris-chart/raphael.js"></script>
<script src="<?=base_url()?>/assets/js/chart/morris-chart/morris.js"> </script>
<script src="<?=base_url()?>/assets/js/chart/morris-chart/prettify.min.js"></script>
<script src="<?=base_url()?>/assets/js/moment.js"></script>
<!-- Year Picker Js -->
<script src="<?=base_url()?>/assets/plugins/year-picker/js/yearpicker.js"></script>

<script>

    $(document).ready(function() {
        // var tahun = <?=date('Y') ?>;
        // chart(tahun); 

        $("#yearpicker").yearpicker({
            year: <?=date('Y')?>,
            startYear: 2018,
            endYear: 2050,
        });
    });

    $('#form-year').on('submit',function(e) {
       e.preventDefault();
      //  var tahun = $('#yearpicker').val();
       var formData = new FormData(this);
      //  chart(tahun);
      $.ajax({
            url: "<?=site_url('analisa/get_data_jual')?>",
            method: "POST",
            contentType:false,
            catch:false,
            processData:false,
            data:formData,
            dataType: "json", //parse the response data as JSON automatically
            success: function(data) {
                console.log(data);
                if (data.msg=="success") {
                   $('#tabel').html(data.table);
                   $('#title').html(data.title);
                }
            }
        });
    });
</script>

