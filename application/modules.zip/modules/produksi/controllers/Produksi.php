<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Produksi extends CI_Controller {

    public function __construct() {
        parent::__construct();
        
    }

    public function index()
    {
        $data['judul'] = 'Produksi Produk';
        $data['title'] = 'Produksi Produk';
		$this->template->load('v_produksi',$data);
    }

}

/*

End of file Produksi.php */


?>