<div class="container-fluid">

<div class="row">
    <!-- Individual column searching (text inputs) Starts-->
    <div class="col-sm-12">
    <div class="card">
        <!-- <div class="card-header">
        <h5>Individual column searching (text inputs) </h5><span>The searching functionality provided by DataTables is useful for quickly search through the information in the table - however the search is global, and you may wish to present controls that search on specific columns.</span>
        </div> -->
        <div class="card-body">
         <!-- Simple demo-->
         <button class="btn btn-primary" type="button" data-toggle="modal" data-original-title="test" data-target="#modal_produk">Tambah Stock Product</button>
        
        <!-- Modal Tambah Product -->
        <div class="modal fade bd-example-modal-lg" id="modal_produk" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Form Tambah Stock Produk</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
                <form class="theme-form" id="form-add-produk">
                <div class="modal-body">
                
                        <div class="form-group row">
                        <label class="col-sm-3 col-form-label" for="inputEmail3">Nama Produk</label>
                        <div class="col-sm-9">
                            <input class="form-control" id="nama_produk" name="nama_produk" type="text" placeholder="Nama Produk" required>
                        </div>
                        </div>
                        <div class="form-group row">
                        <label class="col-sm-3 col-form-label" for="inputEmail3">Deskripsi Produk</label>
                        <div class="col-sm-9">
                            <textarea class="form-control" id="deskripsi_produk" name="deskripsi_produk" type="text" placeholder="Deskripsi Produk" required></textarea>
                        </div>
                        </div>
                        <div class="form-group row">
                        <label class="col-sm-3 col-form-label" for="inputPassword3">Satuan</label>
                        <div class="col-sm-9">
                            <input class="form-control" id="satuan" name="satuan" type="text" placeholder="Satuan" required>
                        </div>
                        </div>
                        <div class="form-group row">
                        <label class="col-sm-3 col-form-label" for="inputPassword3">Harga Beli</label>
                        <div class="col-sm-9">
                            <input class="form-control input-harga" id="harga_beli" name="harga_beli" type="number" placeholder="Harga Beli" required>
                        </div>
                        </div>
                        <div class="form-group row">
                        <label class="col-sm-3 col-form-label" for="inputPassword3">Harga Jual</label>
                        <div class="col-sm-9">
                            <input class="form-control input-harga" id="harga_jual" name="harga_jual" type="number" placeholder="Harga Beli" required>
                        </div>
                        </div>
                        <div class="form-group row">
                        <label class="col-sm-3 col-form-label" for="inputPassword3">Lead Time ( hari )</label>
                        <div class="col-sm-9">
                            <input class="form-control" id="lead_time" name="lead_time" type="number" placeholder="Lead Time" required>
                        </div>
                        </div>
                        <div class="form-group row">
                        <label class="col-sm-3 col-form-label" for="inputPassword3">Foto Produck ( max : 400 kb ) </label>
                        <div class="col-sm-9">
                            <div class="file-loading">
                                <input id="userfile" type="file" name="userfile">
                            </div>
                        </div>
                        </div>
                </div>
                <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Close</button>
                <button class="btn btn-secondary" type="submit" name="submit">Save changes</button>
                </div>
                </form>
            </div>
            </div>
        </div>
       
       <!-- Modal Produksi -->
        <div class="modal fade bd-example-modal-lg" id="modal_produk" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Form Tambah Stock Produk</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
                <form class="theme-form" id="form-add-produk">
                <div class="modal-body">
                
                        <div class="form-group row">
                        <label class="col-sm-3 col-form-label" for="inputEmail3">Nama Produk</label>
                        <div class="col-sm-9">
                            <input class="form-control" id="nama_produk" name="nama_produk" type="text" placeholder="Nama Produk" required>
                        </div>
                        </div>
                        <div class="form-group row">
                        <label class="col-sm-3 col-form-label" for="inputEmail3">Deskripsi Produk</label>
                        <div class="col-sm-9">
                            <textarea class="form-control" id="deskripsi_produk" name="deskripsi_produk" type="text" placeholder="Deskripsi Produk" required></textarea>
                        </div>
                        </div>
                        <div class="form-group row">
                        <label class="col-sm-3 col-form-label" for="inputPassword3">Satuan</label>
                        <div class="col-sm-9">
                            <input class="form-control" id="satuan" name="satuan" type="text" placeholder="Satuan" required>
                        </div>
                        </div>
                        <div class="form-group row">
                        <label class="col-sm-3 col-form-label" for="inputPassword3">Harga Beli</label>
                        <div class="col-sm-9">
                            <input class="form-control input-harga" id="harga_beli" name="harga_beli" type="number" placeholder="Harga Beli" required>
                        </div>
                        </div>
                        <div class="form-group row">
                        <label class="col-sm-3 col-form-label" for="inputPassword3">Harga Jual</label>
                        <div class="col-sm-9">
                            <input class="form-control input-harga" id="harga_jual" name="harga_jual" type="number" placeholder="Harga Beli" required>
                        </div>
                        </div>
                        <div class="form-group row">
                        <label class="col-sm-3 col-form-label" for="inputPassword3">Lead Time ( hari )</label>
                        <div class="col-sm-9">
                            <input class="form-control" id="lead_time" name="lead_time" type="number" placeholder="Lead Time" required>
                        </div>
                        </div>
                        <div class="form-group row">
                        <label class="col-sm-3 col-form-label" for="inputPassword3">Foto Produck ( max : 400 kb ) </label>
                        <div class="col-sm-9">
                            <div class="file-loading">
                                <input id="userfile" type="file" name="userfile">
                            </div>
                        </div>
                        </div>
                </div>
                <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Close</button>
                <button class="btn btn-secondary" type="submit" name="submit">Save changes</button>
                </div>
                </form>
            </div>
            </div>
        </div>


        <div class="table-responsive product-table">
            <table class="display" id="table-produk">
            <thead>
                <tr>
                <th>Foto</th>
                <th>Nama Produk</th>
                <th>Harga Beli</th>
                <th>Harga Jual</th>
                <th>Lead Time</th>
                <th>Stock</th>
                <th>Status</th>
                <th>Action</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
            </table>
        </div>
        </div>
    </div>
    </div>
    <!-- Individual column searching (text inputs) Ends-->
</div>

</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>
<script src="<?=base_url()?>/assets/js/autonumeric/autoNumeric.js"></script>