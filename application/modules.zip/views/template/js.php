
<!-- Plugins JS start-->
<script src="<?=base_url()?>/assets/js/tooltip-init.js"></script>
<script src="<?=base_url('assets/');?>js/sweet-alert/sweetalert2.min.js"></script>
 <!-- feather icon js-->
 <script src="<?=base_url()?>/assets/js/icons/feather-icon/feather.min.js"></script>
<script src="<?=base_url()?>/assets/js/icons/feather-icon/feather-icon.js"></script>
<!-- Sidebar jquery-->
<script src="<?=base_url()?>/assets/js/sidebar-menu.js"></script>
<script src="<?=base_url()?>/assets/js/config.js"></script>
<!-- <script src="<?=base_url()?>/assets/js/prism/prism.min.js"></script> -->
<script src="<?=base_url()?>/assets/js/clipboard/clipboard.min.js"></script>
<script src="<?=base_url()?>/assets/js/counter/jquery.waypoints.min.js"></script>
<script src="<?=base_url()?>/assets/js/counter/jquery.counterup.min.js"></script>
<script src="<?=base_url()?>/assets/js/counter/counter-custom.js"></script>
<script src="<?=base_url()?>/assets/js/custom-card/custom-card.js"></script>
<script src="<?=base_url()?>/assets/js/datepicker/date-picker/datepicker.js"></script>
<script src="<?=base_url()?>/assets/js/datepicker/date-picker/datepicker.en.js"></script>
<script src="<?=base_url()?>/assets/js/datepicker/date-picker/datepicker.custom.js"></script>
<script src="<?=base_url()?>/assets/js/owlcarousel/owl.carousel.js"></script>
<script src="<?=base_url()?>/assets/js/general-widget.js"></script>
<script src="<?=base_url()?>/assets/js/height-equal.js"></script>
<script src="<?=base_url()?>/assets/js/tooltip-init.js"></script>
<script src="<?=base_url()?>/assets/js/ecommerce.js"></script>
<!-- <script src="<?=base_url()?>/assets/js/product-list-custom.js"></script> -->
<script src="<?=base_url()?>/assets/js/form-validation-custom.js"></script>
<script src="<?=base_url()?>/assets/js/notify/bootstrap-notify.min.js"></script>
<script src="<?=base_url()?>/assets/js/notify/notify-script.js"></script>
<script src="<?=base_url()?>/assets/js/rating/jquery.barrating.js"></script>
<script src="<?=base_url()?>/assets/js/rating/rating-script.js"></script>
<!-- Plugins JS Ends-->
<!-- Theme js-->
<script src="<?=base_url()?>/assets/js/script.js"></script>
<script src="<?=base_url()?>/assets/js/theme-customizer/customizer.js"></script>
<!-- login js-->
<!-- Plugin used-->